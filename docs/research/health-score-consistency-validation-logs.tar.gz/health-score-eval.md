# Health score consistency evaluation handoff

Stage verdict: **PASS for targeted offline regression and installation checks**.
No real model was called. No frozen study, raw archive, original answer, annotation,
old case or historical result was edited. No new risk code or mode was introduced,
so the structural eval inventory remains 64 rather than adding unrelated scenarios.

## Findings fed back to author

The initial helper required risk codes for every finding, but the observed AS-21
input supplies only an already adjudicated, capped severity ledger. Requiring
codes would force fabricated details or make the helper unusable for that input.
The author added an explicit `suppliedCappedLedger` assertion, optional codes only
under that assertion, visible missing-code output and a separately reported
unverified debt per-risk cap. Tests use the actual frozen AS-21 severity input
with positional reference IDs and no fabricated codes. The assertion does not
bypass the three-finding cap or known-code debt cap.

Root independently found the symlink CLI entry problem. The author fixed main
entry detection. Tests invoke both direct and symlink paths for render, check and
invalid command handling; the symlink cannot silently exit zero without output.

## Task-owned files

- `scripts/health-dashboard.test.mjs`: eight focused offline tests.
- `scripts/npm-install.test.mjs`: verify helper/schema preservation and execution
  from the npm-installed artifact after deleting the unpacked package; add a
  standalone shell-installer execution check; isolate `npm pack`'s cache.
- `package.json`: add the health test file to the existing `npm test` command only.

## Coverage

1. Literal strict/balanced/legacy expected component scores and composite totals;
   compare deductions against the canonical common.md table, including default.
2. SR-03 exact half-up boundary and no-diff denominator; clean assessed PR is 100,
   skipped PR is omitted; helper weights match the guide's published table.
3. SR-04 missing test assessment and every required unknown dimension: keep its
   weight and suppress the composite; reject inventing a numeric total.
4. Canonical report checks: stale 77 headline, changed component table, altered
   numerator/denominator, duplicated blocks and both observed bold-label forms;
   accept CRLF; explicitly retain bounded checker scope.
5. Actual AS-21 completed raw response extracted read-only from the archived run;
   archive and answer hashes match committed manifest/annotation; both 77 and 80
   labels remain present and the old report fails the new output contract.
6. Actual frozen AS-21 severity-only input computes 92/40/98/100, 7950/100 -> 80
   without adding risk codes; missing assertion/invalid type and cap bypass fail.
7. Missing and unknown schema fields, malformed findings, invalid severities and
   codes, duplicate IDs, skipped/unassessed misuse, three-finding and debt-risk
   caps, plus input immutability.
8. Direct/symlink CLI render/check, malformed JSON and argument errors.
9. npm-packed and standalone shell-installed helper/schema exist and execute
   with no dependency on an unpacked package or local repository imports.

Maximum strict deduction under the three-finding cap is 60. These cases cannot
reach the zero floor and do not claim to exercise it. This is deterministic
arithmetic/block-integrity and installation coverage, not evidence of semantic
finding truth, native model tool use or model adherence. Unrelated prose remains
outside the block checker; no broad natural-language verifier is claimed.

## Validation and preserved failure

The initial combined targeted run passed 14/15 tests and failed only npm packing,
which tried to write to the sandbox-protected global npm cache. A selected failure
diagnostic is preserved in `health-score-eval/initial-cache-failure.txt` (explicitly
an excerpt, not a full transcript). The test now passes a temporary `--cache`
inside its fixture. Global cache contents and configuration were not changed.
An earlier test-authoring error used the annotation wrapper as an array; corrected
to read its `annotations` member before final validation.

Final commands all exited zero:

- `node --test scripts/health-dashboard.test.mjs scripts/npm-install.test.mjs`:
  15 passed, 0 failed, 0 skipped (eight health tests and seven installer tests).
- `npm run evals`: all 64 structural scenarios pass.
- `git diff --check`: clean.

Full captured final outputs are under `_workspace/brooks-harness/health-score-eval/`.
No commit or push performed by this stage. Independent full QA is next.
