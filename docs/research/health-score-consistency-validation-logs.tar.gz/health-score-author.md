# Health score consistency author handoff

## Diagnosis

- **Symptom:** completed response `b9d405c4866db92c56b6` publishes 77/100 while
  its own dimension calculation gives 79.5 and rounds to 80/100.
- **Source:** the guide asked the model to reuse and check a value, but the report
  still separately composed a headline and later arithmetic. There was no
  executable score-block construction or integrity check. This is a procedural
  gap, not evidence that the configured weights are wrong.
- **Consequence:** a plausible-looking report can expose a wrong machine-readable
  headline despite correct supporting arithmetic. Prior guideline-only revision
  did not eliminate this observed failure.
- **Remedy:** finish an explicit adjudicated ledger before composing the report;
  render one canonical block using the optional packaged helper and verify that
  block in the final report. Remove independent repetitions of the composite.
  Preserve an honest, checkable text-only fallback when execution is prohibited.

## Owned changes

- `skills/brooks-health/SKILL.md`: Process items 2–3 point to ledger-first render
  and one verified score block. Description unchanged; three guide steps remain.
- `skills/brooks-health/health-guide.md`: replaces reuse-in-many-places with one
  authoritative score block; helper instructions, error behavior and a complete
  inline fallback that needs neither tool access nor an extra supplied file;
  template no longer invites a provisional independently written headline.
- `skills/brooks-health/score-ledger.md`: exact input schema, use examples,
  custom-risk/configuration responsibilities, CLI render/check, verification
  limitations and portable text-only fallback.
- `skills/brooks-health/scripts/score-dashboard.mjs`: dependency-free Node ESM
  arithmetic, canonical renderer and bounded block-integrity verifier.

No new risk codes, guide steps, frontmatter description changes, frozen study
edits, source/raw response rewrites, package changes, commits or live calls.

## Helper API and boundaries

Exports `calculateDashboard(ledger)`, `renderScoreBlock(ledger)` and
`verifyScoreBlock(ledger, report)`. CLI: `render LEDGER.json` or
`check LEDGER.json REPORT.md`. It reads provided files and writes stdout only.

Input uses resolved `strictness` (omission defaults balanced), boolean `hasDiff`
and exact `dimensions` keys `pr`, `architecture`, `debt`, `test`. Assessed entries
carry `findings: [{id,risk,severity}]`; unassessed/skipped entries carry a reason,
not findings. No-diff PR must be skipped; all other dimensions remain assessed
or explicitly unknown. Missing dimensions and unknown fields fail closed.

The helper enforces three retained findings per dimension, two per debt risk,
unique IDs within each dimension, supported severities and syntactic risk codes.
It uses integer weights 25/30/25/20, floors dimensions before weighting, rounds
once half-up, and suppresses an incomplete composite. It does not validate custom
risk definitions, diagnose findings, select caps, parse YAML, or verify arbitrary
prose. Config validation/fallback and semantic adjudication precede the helper.

Verifier requires the exact canonical block once and counts additional Composite
Score labels regardless of common bold-colon placement. It does not claim broad
report semantics verification. Guide forbids repeated totals outside the block;
surrounding prose remains an explicit review obligation. Text-only evaluation
cannot establish helper execution; offline helper correctness is not model
adherence evidence.

## Author validation

`node --check skills/brooks-health/scripts/score-dashboard.mjs` and
`git diff --check` passed. A direct independent AS-21 witness used strict scores
92,40,98,100: N=7950, D=100, composite=80. Canonical block passed verification;
changing headline to 77 failed; appending `**Composite Score: 80/100**` failed.
Eval-curator should add durable positive, negative, incomplete-input, alternate
bold-label, caps, no-diff, rounding, CLI and portability boundary coverage. QA
owns the full repository gate after that stage.

## Author loopback: symlink CLI entry

Root found that launching through `.agents/skills/brooks-health/scripts/` did
not enter the CLI: Node resolved `import.meta.url` to the real file while argv
retained the symlink path. Both paths are now compared through `realpathSync`,
with absent/unresolvable argv treated as import-only. This preserves normal
module imports and supports both direct and symlink skill installations.

## Author loopback: supplied severity-only ledgers

AS-21 supplies a capped adjudicated severity ledger without risk codes or finding
IDs. The original manual witness added synthetic risks and therefore established
only arithmetic behavior, not direct source-ledger compatibility. The helper now
accepts an explicit `suppliedCappedLedger: true` input assertion and omitted risk
fields. Positional IDs remain references to source entries, not new diagnoses.
Known risk-code caps still apply; missing debt codes yield an explicit unverified
per-risk-cap statement. A supplied-ledger assertion never bypasses known cap
violations or the three-finding dimension cap. Ordinary diagnosed inputs still
require risk codes. The regression must transform only field names/case and assign
positional references to AS-21; it must not invent risks.
