# Frozen scoring

This is a single three-arm pilot on a new admitted case. The candidates share
a task, writable environment, model, effort and deadline and see only their
assigned guidance. The source probe and mutation stay with the evaluator.

- Map both sync and async wrappers, the relationship between AsyncRetrying.wraps
  and the base wrapper, and the public retry_with path.
- Trace template configuration and per-invocation controller creation to the
  actual bound retry controller. A route is evidenced by selection/delegation
  code or a test asserting the behavior through the public route.
- Preserve distinct per-call controllers for the same wrapper, including
  overlapping async invocations. Preserve runtime copy overrides. Preserve the original observability policy
  in the candidate; the historical upstream change intentionally evolves it.
- Credit a decision only when a traced route changes the source boundary or
  an authored test detects the admitted mutation while both comparators miss
  it. Give separate credit for a fuller report. Run original patches intact.

The exact async source mutant must apply and fail the independent assertion
while the pristine base and full default base suite with the mutant pass.
An evaluator-side patch of AsyncRetrying.copy() for calls without configuration
arguments is an additional way to challenge tests against different extraction
shapes. The full inherited suite and independent probe validate this broader
substitution before generation. Report both forms and distinguish existing
test coverage from candidate-authored tests.
