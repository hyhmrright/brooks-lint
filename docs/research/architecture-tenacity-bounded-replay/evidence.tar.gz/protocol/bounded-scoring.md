# Frozen paired replay of the wait-bound rule

Keep the original Tenacity base, task, before-generation probe, source
mutation, runtime mutation, model, effort, tooling and 240-second deadline.
Run two independent fresh blocks. Each block has the generic checklist and
the two adjacent guides, 8b67513 and ee5be61. The only guide difference is
the five added lines about bounded regression fixtures. Earlier runs are
historical context and do not count in the six new observations.

Verify exact captured diffs on fresh copies. Run full pytest, pinned Mypy,
Ruff lint and formatting, Sphinx doctest and HTML. Compare modern Ruff
diagnostics to the unchanged base and repeat its compatibility check with
0.15.7. The independent override probe must pass on the original candidate.

For each arm, record whether its authored or substantively changed tests:
1. Pass in the original candidate and exercise the relevant production route.
2. Exercise an actual async subclass override, or an instance interception,
   or neither. Record whether retry_with and overlap are included.
3. Include intentional fixture-level bounds and the underlying error or
   assertion behavior, apart from the evaluator's 10-second deadline.
4. Detect the frozen async copy-override bypass under the identical runtime
   substitution. Classify prompt assertion or causal error, timeout, or
   survival separately. Missing/failed pristine tests or unusable patches
   remain separate outcomes. Count no tests by their titles or prose alone.

Benefit threshold for this pilot: the new guide explicitly bounds the
affected fixture and its authored tests detect the mutation promptly in
both blocks, with fewer prompt detections or a timeout in a comparator.
Compare source seams separately. A two-block replay of a case that motivated
the rule is evidence for that case, with generalization unmeasured.
