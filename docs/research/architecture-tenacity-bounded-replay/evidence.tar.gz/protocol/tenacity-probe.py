import asyncio
import inspect

from tenacity import AsyncRetrying, Retrying, RetryCallState


def check_sync():
    seen = []

    class SyncPolicy(Retrying):
        pass

    def before(state: RetryCallState):
        seen.append(state.retry_object)

    decorated = SyncPolicy().wraps(lambda value: value + 1)
    configured = decorated.retry_with(before=before)
    assert configured.retry is not decorated.retry
    assert type(configured.retry) is SyncPolicy
    assert configured(1) == 2
    assert configured(4) == 5
    assert len(seen) == 2
    assert all(type(call) is SyncPolicy and call is not configured.retry for call in seen)
    assert seen[0] is not seen[1]


async def check_async():
    seen = []
    both_entered = asyncio.Event()
    calls_entered = 0

    class AsyncPolicy(AsyncRetrying):
        def copy(self, *args, **kwargs):
            controller = super().copy(*args, **kwargs)
            controller.copy_was_overridden = True
            return controller

    async def callback(state: RetryCallState):
        seen.append(state.retry_object)

    async def target(value):
        nonlocal calls_entered
        calls_entered += 1
        if calls_entered == 2:
            both_entered.set()
        await both_entered.wait()
        return value + 1

    decorated = AsyncPolicy().wraps(target)
    configured = decorated.retry_with(before=callback)
    assert inspect.iscoroutinefunction(configured)
    assert configured.retry is not decorated.retry
    assert type(configured.retry) is AsyncPolicy
    observed = await asyncio.wait_for(asyncio.gather(configured(10), configured(20)), timeout=2)
    assert observed == [11, 21]
    assert len(seen) == 2
    assert all(type(call) is AsyncPolicy and call is not configured.retry for call in seen)
    assert seen[0] is not seen[1]
    assert all(getattr(call, "copy_was_overridden", False) for call in seen)


check_sync()
asyncio.run(check_async())
print("sync and async retry_with override dispatch and per-invocation copies passed")
