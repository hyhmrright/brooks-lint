"""Bypass overridden copy dispatch on the async invocation route."""
from pathlib import Path

path = Path("tenacity/asyncio/__init__.py")
source = path.read_text()
old = "            copy = self.copy()"
assert source.count(old) == 1
path.write_text(source.replace(old, "            copy = BaseRetrying.copy(self)", 1))
