"""Challenge async dynamic dispatch independently of the source factoring."""
from functools import wraps

from tenacity import AsyncRetrying, BaseRetrying

original_select = AsyncRetrying.__getattribute__


def select(self, name):
    selected = original_select(self, name)
    if name != "copy":
        return selected

    @wraps(selected)
    def copy(*args, **kwargs):
        if args or kwargs:
            return selected(*args, **kwargs)
        return BaseRetrying.copy(self)

    return copy


AsyncRetrying.__getattribute__ = select
