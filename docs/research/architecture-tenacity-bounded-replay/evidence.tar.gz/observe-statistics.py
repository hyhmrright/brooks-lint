"""Observe the statistics contract across the historical replay."""
import asyncio
from functools import wraps
import json

from tenacity import retry, stop_after_attempt


def outerify(inner):
    @wraps(inner)
    def outer(*args, **kwargs):
        return inner(*args, **kwargs)

    return outer


@retry(stop=stop_after_attempt(2))
def sync_target():
    return 17


@retry(stop=stop_after_attempt(2))
async def async_target():
    return 17


def observation(outer):
    inner = outer.__wrapped__
    return {
        "outer_attempts": outer.statistics.get("attempt_number"),
        "inner_attempts": inner.statistics.get("attempt_number"),
        "same_outer_and_inner": outer.statistics is inner.statistics,
        "same_inner_and_template": inner.statistics is inner.retry.statistics,
    }


sync = outerify(sync_target)
assert sync() == 17
other = outerify(async_target)
assert asyncio.run(other()) == 17
print(json.dumps({"sync": observation(sync), "async": observation(other)}, sort_keys=True))
