#!/usr/bin/env bash
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
variant="$1"
tree="$root/docs-$variant"
logs="$root/verification-docs/$variant"
mkdir -p "$logs"
revision="$(sed -n '2p' "$root/tenacity.refs")"
if [ "$variant" = upstream ]; then revision="$(sed -n '1p' "$root/tenacity.refs")"; fi
if [ ! -d "$tree" ]; then git -C "$root/docs-history" worktree add -q --detach "$tree" "$revision"; fi
cd "$tree"
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  git apply --check "$root/results-proxy/tenacity/$variant/candidate.patch"
  git apply "$root/results-proxy/tenacity/$variant/candidate.patch"
fi
export PYTHONPATH="$tree" PYTHONDONTWRITEBYTECODE=1
for mode in doctest html; do
  check_rc=0
  "$root/venv-tenacity-docs/bin/sphinx-build" -a -E -W -b "$mode" doc/source "$logs/$mode-output" > "$logs/$mode.log" 2>&1 || check_rc="$?"
  printf '%s\t%s\n' "$mode" "$check_rc" >> "$logs/status.tsv"
done
