#!/usr/bin/env bash
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
variant="$1"
run="$root/verification/$variant"
tree="$run/tree"
logs="$run/logs"
mkdir -p "$logs"
mkdir "$tree"
archive="$root/tenacity-base.tgz"
if [ "$variant" = upstream ]; then archive="$root/tenacity-upstream.tgz"; fi
tar -xzf "$archive" -C "$tree"
cd "$tree"
git init -q
export PATH="$root/venv-tenacity/bin:$PATH"
export PYTHONPATH="$tree" PYTHONDONTWRITEBYTECODE=1
record() {
  local name="$1"
  shift
  local check_rc=0
  {
    printf '%q ' "$@"
    printf '\n'
    "$@"
  } > "$logs/$name.log" 2>&1 || check_rc="$?"
  printf '%s\t%s\n' "$name" "$check_rc" >> "$logs/status.tsv"
  printf '\nEXIT %s\n' "$check_rc" >> "$logs/$name.log"
  return "$check_rc"
}
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  patch="$root/results-proxy/tenacity/$variant/candidate.patch"
  test -s "$patch"
  record apply-check git apply --check "$patch"
  record apply git apply "$patch"
  git apply --numstat "$patch" | cut -f3 > "$logs/changed-files.txt"
  record syntax python "$root/syntax.py" "$logs/changed-files.txt" || true
fi
record probe python "$root/protocol/tenacity-probe.py" || true
record suite python "$root/deadline.py" 30 python -m pytest -q -p no:cacheprovider tests || true
record ruff ruff check . || true
record ruff-format ruff format --check . || true
record mypy mypy || true
