"""Measure how original authored tests respond to a broken statistics binding."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
variants = ("checklist", "audit-before", "audit-after")
blocks = ("block-1", "block-2")
old = "        self._local.statistics = copy.statistics\n"
new = "        self._local.statistics = {}\n"


def run(block, variant):
    source = root / block / "verification" / variant
    dest = root / "failure-bound-diagnostic" / block / variant
    dest.mkdir(parents=True)
    tree = dest / "tree"
    shutil.copytree(source / "tree", tree,
                    ignore=shutil.ignore_patterns(".git", "__pycache__", ".ruff_cache", ".pytest_cache", ".mypy_cache"))
    code = tree / "tenacity/__init__.py"
    text = code.read_text()
    assert text.count(old) == 1, (block, variant)
    code.write_text(text.replace(old, new, 1))
    checks = json.loads((source / "logs/mutation-result.json").read_text())
    assert checks["pristine_authored_exit"] == 0
    selectors = [
        selector for selector in checks["authored_selectors"]
        if selector.startswith("tests/test_asyncio.py::")
    ]
    assert selectors
    py = str(root / block / "venv-tenacity/bin/python")
    env = dict(os.environ, PYTHONPATH=str(tree), PYTHONDONTWRITEBYTECODE="1")
    with (dest / "probe.log").open("wb") as log:
        observation = subprocess.run(
            [py, str(root / block / "observe-statistics.py")], cwd=tree, env=env,
            stdout=log, stderr=subprocess.STDOUT, timeout=5, check=True,
        )
    output = json.loads((dest / "probe.log").read_text())
    assert observation.returncode == 0 and not output["async"]["same_inner_and_template"]
    with (dest / "authored.log").open("wb") as log:
        result = subprocess.run(
            [py, str(root / "deadline.py"), "10", py, "-m", "pytest", "-q", "-p", "no:cacheprovider", *selectors],
            cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT,
        )
    return {"block": block, "condition": variant, "authored_selectors": selectors,
            "mutated_authored_exit": result.returncode, "observation": output}


with ThreadPoolExecutor(max_workers=6) as pool:
    futures = [pool.submit(run, block, variant) for block in blocks for variant in variants]
    receipts = [future.result() for future in futures]
(root / "failure-bound-diagnostic/results.json").write_text(json.dumps(receipts, indent=2) + "\n")
