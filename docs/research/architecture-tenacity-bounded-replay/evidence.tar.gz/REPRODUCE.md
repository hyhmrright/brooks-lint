# Reproduce the paired Tenacity replay

Use CPython 3.11.18, Git and uv on a POSIX host. Extract this bundle into an
empty writable directory. It includes all six exact patches and model
receipts. Independent verification needs no model calls.

```sh
shasum -a 256 -c SHA256SUMS
shasum -a 256 -c PROTOCOL.sha256
bash prepare-snapshots.sh
python3.11 -m venv venv-tenacity
venv-tenacity/bin/python -m pip install -r tenacity.freeze
python3.11 -m venv venv-ruff-0157
venv-ruff-0157/bin/python -m pip install ruff==0.15.7
mkdir base wheel-source
tar -xzf tenacity-base.tgz -C base
tar -xzf tenacity-base.tgz -C wheel-source
SETUPTOOLS_SCM_PRETEND_VERSION=9.1.4 uv build --wheel --out-dir wheel wheel-source
python3.11 -m venv venv-tenacity-docs
venv-tenacity-docs/bin/python -m pip install -r docs-dependencies.freeze wheel/tenacity-9.1.4-py3-none-any.whl
git clone --no-checkout https://github.com/jd/tenacity.git docs-history
for block in block-1 block-2; do
  cp verify.sh verify-docs.sh assess.py syntax.py deadline.py observe-statistics.py tenacity.refs "$block/"
  cp -R protocol "$block/"
  for file in tenacity-base.tgz tenacity-upstream.tgz base venv-tenacity venv-ruff-0157 venv-tenacity-docs docs-history; do
    ln -s "../$file" "$block/$file"
  done
done
bash evaluate-block.sh block-1 base upstream
bash evaluate-block.sh block-1 checklist audit-before audit-after
bash evaluate-block.sh block-2 checklist audit-before audit-after
```

The full candidate suites have a 30-second external safety limit. The
authored-test mutation replay uses the frozen 10-second evaluator deadline.
These limits are distinct from any retry limit in candidate code. Read
`results.json` or the new verification logs for exit codes. Compare the
primary benchmark's distinct criteria in `protocol/bounded-scoring.md`.

Computing the original receipt also compares Ruff 0.16.8 diagnostics by
rule, path and message against the base, independent of shifted lines.
For the compatibility pass, `evaluate-block.sh` runs Ruff 0.15.7 with the
unchanged project configuration. Documentation builders use the actual
Git history for reno and source from the corresponding worktree.

To reproduce the separate diagnostic after replaying block 2, copy the
pristine verified tree to a new location and apply only the diagnostic
test patch there. Using an absolute path to this bundle ensures the
mutation plugin is importable.

```sh
bundle="$PWD"
cp -R block-2/verification/audit-after/tree diagnostic/tree
(
  cd diagnostic/tree
  git apply "$bundle/diagnostic/assert-copy-dispatch.patch"
  export PYTHONPATH="$PWD:$bundle/protocol" PYTHONDONTWRITEBYTECODE=1
  python_bin="$bundle/venv-tenacity/bin/python"
  case_id=tests/test_asyncio.py::TestDecoratorWrapper::test_nested_calls_keep_each_controller_context
  "$python_bin" "$bundle/deadline.py" 10 "$python_bin" -m pytest -q "$case_id"
  "$python_bin" "$bundle/deadline.py" 10 "$python_bin" -m pytest -q -p async_copy_mutation "$case_id"
)
```

The diagnostic's pristine run should pass. Its mutated run should fail
the `copies == controllers` assertion with pytest exit code 1.

To run the separate statistics-alias failure diagnostic after verifying all
six trees, invoke `python3 diagnose-failure-bound.py` from the bundle root.
It uses disposable copies and the same original async test selectors.
Expected outcomes are 10-second timeouts in both older and checklist
runs and exit 1 in both revised runs. The generated `authored.log` shows the
causal error when the fixture bounds retries.
