#!/usr/bin/env bash
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
cd "$root/$1"
shift
evaluate() {
  local variant="$1" check_rc=0
  if ! bash verify.sh "$variant"; then
    return 1
  fi
  (
    cd "verification/$variant/tree"
    "../../../venv-ruff-0157/bin/ruff" check . || check_rc="$?"
    printf '\nEXIT %s\n' "$check_rc"
  ) > "verification/$variant/logs/ruff-0157.log" 2>&1
  (
    cd "verification/$variant/tree"
    PYTHONPATH="$PWD" "../../../venv-tenacity/bin/python" "../../../observe-statistics.py"
  ) > "verification/$variant/logs/statistics.json"
  if [ "$variant" != base ] && [ "$variant" != upstream ]; then
    python3 assess.py "$variant"
  fi
}
jobs=()
for variant in "$@"; do
  evaluate "$variant" &
  jobs+=("$!")
  bash verify-docs.sh "$variant" &
  jobs+=("$!")
done
outcome=0
for job in "${jobs[@]}"; do wait "$job" || outcome=1; done
exit "$outcome"
