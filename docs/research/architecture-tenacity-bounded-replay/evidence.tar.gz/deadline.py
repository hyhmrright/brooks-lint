"""Bound a replay command independently of the candidate fixture."""
import os
import signal
import subprocess
import sys

process = subprocess.Popen(sys.argv[2:], start_new_session=True)
try:
    result = process.wait(timeout=float(sys.argv[1]))
except subprocess.TimeoutExpired:
    os.killpg(process.pid, signal.SIGKILL)
    process.wait()
    print(f"Evaluator deadline exceeded: {sys.argv[1]} seconds.", file=sys.stderr)
    result = 124
raise SystemExit(result)
