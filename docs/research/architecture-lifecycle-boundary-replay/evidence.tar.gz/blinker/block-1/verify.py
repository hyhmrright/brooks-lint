"""Reapply exact patches and record complete checks and isolated mutations."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BIN = ROOT / "venv-blinker" / "bin"
RESULTS = ROOT / "results-proxy" / "blinker"
VERIFY = ROOT / "verification"
SOURCES = ("base", "upstream", "checklist", "audit-before", "audit-after")


def execute(logs, tree, name, *command, deadline=45, python_extra=()):
    env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(tree / "src"), *map(str, python_extra)]))
    env["PATH"] = os.pathsep.join([str(BIN), env["PATH"]])
    try:
        result = subprocess.run(command, cwd=tree, env=env, check=False,
                                capture_output=True, text=True, timeout=deadline)
        message = result.stdout + result.stderr
        code = result.returncode
    except subprocess.TimeoutExpired as exc:
        message = (exc.stdout or b"").decode(errors="replace")
        message += (exc.stderr or b"").decode(errors="replace")
        code = 124
    (logs / f"{name}.log").write_text(f"$ {' '.join(map(str, command))}\n{message}\nEXIT {code}\n")
    return code


def verify(source):
    dest = VERIFY / source
    tree = dest / "tree"
    logs = dest / "logs"
    tree.mkdir(parents=True)
    logs.mkdir()
    subprocess.run(["tar", "-xf", ROOT / "blinker-base.tgz", "-C", tree], check=True)
    patch = ROOT / "upstream.patch" if source == "upstream" else RESULTS / source / "candidate.patch"
    statuses = {}
    if source != "base":
        for key, flags in (("apply-check", ["--check"]), ("apply", [])):
            statuses[key] = execute(logs, tree, key, "git", "apply", *flags, patch)
            if statuses[key]:
                return statuses

    hook_commands = {
        "check-merge-conflict": "check-merge-conflict",
        "debug-statements": "debug-statement-hook",
        "fix-byte-order-marker": "fix-byte-order-marker",
        "trailing-whitespace": "trailing-whitespace-fixer",
        "end-of-file-fixer": "end-of-file-fixer",
    }
    # Run potentially fixing hooks on a copy. Previous stages always inspect the
    # exact raw candidate, and these hooks cannot repair a candidate in place.
    hook_tree = dest / "style"
    shutil.copytree(tree, hook_tree)
    paths = [path.relative_to(hook_tree).as_posix()
             for path in sorted(hook_tree.rglob("*")) if path.is_file()]
    statuses["style-git"] = execute(logs, hook_tree, "style-git", "git", "init", "-q")
    py_files = [path for path in paths if path.endswith(".py")]
    text_files = [path for path in paths if not path.endswith(".png")]
    for name, executable in hook_commands.items():
        selected = py_files if name == "debug-statements" else text_files
        statuses[name] = execute(logs, hook_tree, name, executable, *selected)

    commands = {
        "syntax": ["python", "-m", "compileall", "-q", "src", "tests"],
        "pytest": ["python", "-m", "pytest", "-q"],
        "collect": ["python", "-m", "pytest", "--collect-only", "-q"],
        "mypy": ["mypy"],
        "ruff-lint": ["ruff", "check", "--no-fix", "."],
        "ruff-format": ["ruff", "format", "--check", "."],
        "pyright": [ROOT / "pyright-node" / "node_modules" / ".bin" / "pyright"],
        "probe": ["python", ROOT / "protocol" / "probe.py"],
    }
    for name, command in commands.items():
        statuses[name] = execute(logs, tree, name, *command)
    statuses["wheel"] = execute(logs, tree, "wheel", "python", "-m", "flit_core.wheel")
    if statuses["wheel"] == 0:
        wheel, = (tree / "dist").glob("*.whl")
        statuses["docs"] = execute(logs, tree, "docs", "sphinx-build", "-E", "-W", "-b",
                                   "dirhtml", "docs", dest / "html", python_extra=(wheel,))
    if source != "upstream":
        mutated = dest / "mutant"
        shutil.copytree(tree, mutated, ignore=shutil.ignore_patterns("*cache*", "__pycache__"))
        statuses["plant"] = execute(logs, mutated, "plant", "python", ROOT / "protocol" / "mutate.py", mutated)
        if statuses["plant"] == 0:
            statuses["mutant-probe"] = execute(logs, mutated, "mutant-probe", *commands["probe"])
            statuses["mutant-pytest"] = execute(logs, mutated, "mutant-pytest", *commands["pytest"])
    return statuses


if __name__ == "__main__":
    sources = tuple(sys.argv[1:]) or SOURCES
    with ThreadPoolExecutor(max_workers=3) as pool:
        summary = dict(zip(sources, pool.map(verify, sources), strict=True))
    print(json.dumps(summary, indent=2))
