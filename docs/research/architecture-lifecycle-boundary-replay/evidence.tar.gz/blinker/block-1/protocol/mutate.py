"""Apply the registration change isolated from upstream 9bc4890."""
from pathlib import Path
import sys

source = Path(sys.argv[1]) / "src/blinker/base.py"
original = "self.receivers.setdefault(receiver_id, receiver_ref)"
mutant = "self.receivers[receiver_id] = receiver_ref"
code = source.read_text()
if code.count(original) != 1:
    raise SystemExit("Expected exactly one original registration site; inspect the candidate.")
source.write_text(code.replace(original, mutant))
