# Frozen Blinker scoring

The patch must apply unchanged; run the complete project pytest suite and pinned
Mypy, Ruff lint and Ruff formatting. Compare static findings with baseline.
Inspect Pyright and complete the project docs build as supplemental checks.
Evaluate each patch with the independent public-entry probe. If the original
patch and its tests pass, apply the same receiver-registration behavior change to
a separate copy. Candidate coverage requires a new test that passes pristine and
fails with the planted behavior change at a relevant assertion. Record a
nonapplicable mutation separately unless its equivalent is independently
demonstrated using the frozen probe. Do not count inherited tests or the probe
toward candidate coverage.

Trace anchors: Namespace.signal/global signal and direct Signal; connect,
connect_via and connected_to; send and send_async via receivers_for; explicit
disconnect and automatic weak receiver and sender cleanup, including the
legacy utility and bound-method reference cache where relevant. Attribute credit
only to traces tied to the selected first cut. Identify whether a proposed cut
would replace first-registration retention and whether the evidence influences
which operation is moved. Score mergeability, runtime trace, functional
preservation and mutation detection independently.
