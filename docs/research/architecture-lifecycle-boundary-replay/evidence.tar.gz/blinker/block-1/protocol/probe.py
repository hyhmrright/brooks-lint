"""Check receiver lifetime through both dispatch entries after re-registration."""
import asyncio
import gc
from weakref import ref

from blinker import Namespace


async def dispatch() -> None:
    def wrap(func):
        async def run(*args, **kwargs):
            return func(*args, **kwargs)

        return run

    for first_is_weak in (False, True):
        namespace = Namespace()
        sig = namespace.signal("update")

        def receive(sender):
            return sender

        receiver_ref = ref(receive)
        sig.connect(receive, sender="first", weak=first_is_weak)
        sig.connect_via("second", weak=not first_is_weak)(receive)
        del receive
        gc.collect()
        assert namespace.signal("update") is sig
        expected_first = [] if first_is_weak else ["first"]
        expected_second = [] if first_is_weak else ["second"]
        sync_result = [value for _, value in namespace.signal("update").send("first")]
        async_result = [
            value for _, value in await namespace.signal("update").send_async(
                "second", _sync_wrapper=wrap
            )
        ]
        assert sync_result == expected_first, (first_is_weak, sync_result)
        assert async_result == expected_second, (first_is_weak, async_result)
        assert (receiver_ref() is None) == first_is_weak


asyncio.run(asyncio.wait_for(dispatch(), timeout=3))
