"""Replay a pytest fixture representation candidate without altering its diff."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BIN = ROOT / "venv-pytest-fixtures" / "bin"
VERIFY = ROOT / "verification"


def verify(name):
    path = VERIFY / name
    tree = path / "tree"
    tree.mkdir(parents=True)
    logs = path / "logs"
    logs.mkdir()
    subprocess.run(["tar", "-xf", ROOT / "pytest-fixtures-base.tgz", "-C", tree], check=True)
    shutil.copyfile(ROOT / "support-version.py", tree / "src" / "_pytest" / "_version.py")
    status = {}

    def run(label, *command, directory=tree, timeout=90):
        env = dict(os.environ, PYTHONPATH=str(directory / "src"),
                   PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                   PATH=f"{BIN}{os.pathsep}{os.environ['PATH']}")
        with (logs / f"{label}.log").open("wb") as output:
            output.write(("$ " + " ".join(map(str, command)) + "\n").encode())
            output.flush()
            try:
                process = subprocess.run(command, cwd=directory, env=env,
                                         stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
                code = process.returncode
            except subprocess.TimeoutExpired:
                code = 124
            output.write(f"\nEXIT {code}\n".encode())
        status[label] = code
        return code

    if name != "base":
        patch = ROOT / "results-proxy" / "pytest-fixtures" / name / "candidate.patch"
        if run("apply-check", "git", "apply", "--check", patch):
            return status
        if run("apply", "git", "apply", patch):
            return status

    probe = ["python", "-m", "pytest", "-c", "/dev/null", "-p", "no:cacheprovider",
             "-q", ROOT / "protocol" / "test_probe.py"]
    run("probe", *probe)
    run("syntax", "python", "-m", "compileall", "-q", "src", "testing")
    run("mypy", "mypy", "--no-incremental")
    run("ruff", "ruff", "check", "--no-fix", ".")
    run("format", "ruff", "format", "--check", ".")
    run("pytest", "python", "-m", "pytest", "-q", timeout=480)

    if name != "base":
        mutant = path / "mutant"
        shutil.copytree(tree, mutant, ignore=shutil.ignore_patterns(".*cache", "__pycache__"))
        if run("plant", "python", ROOT / "protocol" / "mutate.py", mutant, directory=mutant) == 0:
            run("mutant-probe", *probe, directory=mutant)
            run("mutant-pytest", "python", "-m", "pytest", "-q", directory=mutant, timeout=480)
    return status


if __name__ == "__main__":
    names = tuple(sys.argv[1:])
    with ThreadPoolExecutor(max_workers=3) as pool:
        print(json.dumps(dict(zip(names, pool.map(verify, names), strict=True)), indent=2))
