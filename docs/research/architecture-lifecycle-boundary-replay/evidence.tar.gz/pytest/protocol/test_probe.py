from functools import wraps

import pytest


def wrapped_fixture(func):
    @wraps(func)
    def wrapped(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapped


@wrapped_fixture
@pytest.fixture(name="named_value")
def value():
    return "from module fixture"


def test_module_fixture(named_value):
    assert named_value == "from module fixture"


class TestReceiver:
    expected = "from bound fixture"

    @wrapped_fixture
    @pytest.fixture
    def bound_value(self):
        return self.expected

    def test_bound_fixture(self, bound_value):
        assert bound_value == self.expected
