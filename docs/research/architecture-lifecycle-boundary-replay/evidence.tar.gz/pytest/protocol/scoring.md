# Frozen pytest scoring

The probe wraps pytest.fixture with functools.wraps, then requests both a named
module fixture and a test-instance method fixture through a real pytest run.
Preserve observed behavior in the first cut. Distinguish this observed legacy
behavior from what the upstream project expressly supports.

Replay candidates unchanged and run the default full suite, pinned Mypy and
Ruff and the independent probe. A mutation is informative only if it rejects
both probe fixtures while the untouched inherited suite passes. Candidate
coverage requires a candidate-authored test that fails for the planted reason.

Trace fixture decoration, collection for modules, classes and plugin holders,
name and receiver binding, request and setup hook, direct-call protection, and
diagnostic consumers of wrapper metadata. Identify the first cut that advances
fixture metadata ownership and which obligations influence its shape.
