"""Reject a wrapped fixture at collection as in the strict representation split."""
from pathlib import Path
import sys

source = Path(sys.argv[1]) / "src/_pytest/fixtures.py"
original = '''    return cast(
        Optional[FixtureFunctionMarker],
        safe_getattr(obj, "_pytestfixturefunction", None),
    )'''
mutant = '''    wrapped = safe_getattr(obj, "__pytest_wrapped__", None)
    if wrapped is not None and safe_getattr(obj, "__wrapped__", None) is not wrapped.obj:
        return None
''' + original
code = source.read_text()
if code.count(original) != 1:
    raise SystemExit("Expected exactly one original fixture marker lookup; inspect the candidate.")
source.write_text(code.replace(original, mutant))
