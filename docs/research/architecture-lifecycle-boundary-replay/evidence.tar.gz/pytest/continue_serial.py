"""Complete each original serial collection after its initial evaluator deadline."""
from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import re
import subprocess
import time

root = Path(__file__).resolve().parent
conditions = ("checklist", "audit-before", "audit-after")


def finish(name):
    tree = root / "verification" / name / "tree"
    original = root / "verification" / name / "logs" / "pytest.log"
    output = root / "continuation" / name
    output.mkdir(exist_ok=True)
    deadline = time.monotonic() + 90
    while "EXIT" not in (progress := original.read_text()):
        if time.monotonic() > deadline:
            raise TimeoutError(original)
        time.sleep(1)
    if "EXIT 124" not in progress:
        (output / "scope.txt").write_text("Initial collection completed.\n")
        return
    marks = "".join(re.findall(r"^([sxXFE.]+)(?:\s*\[|\s*$)", progress, re.M))
    env = dict(os.environ, PYTHONPATH=str(tree / "src"), TERM="xterm-256color",
               PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
               PATH=f'{root}/venv-pytest-fixtures/bin{os.pathsep}{os.environ["PATH"]}')
    command = [str(root / "venv-pytest-fixtures" / "bin" / "python"), "-m", "pytest"]
    listing = subprocess.check_output([*command, "-q", "--collect-only"], env=env,
                                      cwd=tree, text=True)
    cases = [line for line in listing.splitlines() if "::" in line and not line.startswith(" ")]
    assert 0 < len(marks) < len(cases), (len(marks), len(cases))
    pending = output / "pending.txt"
    pending.write_text("\n".join(cases[len(marks):]) + "\n")
    (output / "scope.txt").write_text(
        f"Completed progress marks: {len(marks)} of {len(cases)}. "
        f"Resumed at {cases[len(marks)]}.\n"
    )
    with (output / "pytest.log").open("w") as log:
        invocation = [*command, "-q", f"@{pending}"]
        log.write("$ " + " ".join(invocation) + "\n")
        log.flush()
        outcome = subprocess.run(invocation, cwd=tree, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=480, check=False)
        log.write(f"\nEXIT {outcome.returncode}\n")


with ThreadPoolExecutor(max_workers=3) as workers:
    list(workers.map(finish, conditions))
