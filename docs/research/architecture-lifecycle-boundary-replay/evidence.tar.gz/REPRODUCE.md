# Reproduce the frozen replays

Run `shasum -a 256 -c SHA256SUMS` from the extracted evidence root. Historical
logs retain paths from the original workspace. Preserve the recorded logs
before replaying by moving each `verification` directory aside.

## Blinker

Each block contains the uncompressed Git archive of the same baseline. From
`blinker/block-1`, with uv, CPython 3.11 and Node available:

```sh
uv venv --python 3.11 venv-blinker
uv pip sync --python venv-blinker/bin/python ../requirements.freeze
npm --prefix pyright-node ci
python3 verify.py
```

From blocks 2 through 4, symlink `venv-blinker` and `pyright-node` to the
environment from block 1. Run `python3 verify.py checklist audit-before
audit-after`. Run the separate block 3 positive control with `python3
verify.py positive-control`.

## Pytest

In a clone of the [official pytest repository](https://github.com/pytest-dev/pytest),
use `git archive <full-parent-sha>` for the first commit in `pytest/refs.txt`.
Save the uncompressed archive as `pytest/pytest-fixtures-base.tgz`. In the
evidence's `pytest` directory create `venv-pytest-fixtures` with Python 3.11
and install `requirements.freeze` with `uv pip sync`. Replay the raw patches
with `python3 verify.py checklist audit-before audit-after`. The evaluator's
serial deadline is 480 seconds. `continue_serial.py` records and resumes the
unexecuted node IDs if a candidate reaches that deadline. The additional
parallel run used `pytest-xdist==3.6.1` and `execnet==2.1.1` (see
`xdist.requirements.freeze`) with `python -m pytest -p xdist -n 4 --dist loadfile -q`.
For the terminal and distribution-metadata rerun, install the reference
baseline with `uv pip install --no-deps --no-build-isolation .` using the same
virtualenv and generated version. Run from a candidate replay tree with its
`src` on `PYTHONPATH`, `TERM=xterm-256color` and
`PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`. See `diagnostic` for those outcomes.

The optional `run_arms.py` scripts perform new live calls and require an
authenticated Codex CLI. Live output can vary. Replaying the frozen patches
requires no model calls or credentials.
