# Development probe record

All probes were offline and used authored fixture responses, never a live model.

1. The initial localhost listener was denied by the filesystem/process sandbox (`listen EPERM 127.0.0.1`), before any CLI spawn. `probe.json` preserves that failure.
2. The first attempt to import the new adapter failed before startup because its helper import resolved one parent directory too far. The eval author fixed the relative import. No output directory or provider request was created by this attempt.
3. The early real CLI adapter probe completed with two local HTTP fixture requests, one host scoring call, an exact final report, and confirmed cleanup. Its raw artifacts are in `adapter/`.
4. The final source-bound proof is the eval stage's `round2-wire/`, after scope hardening and the QA reporting correction. Earlier probe evidence is developmental, not the final frozen candidate's result.

The first QA review found baseline A mechanical metrics incorrectly displayed as zero passed prohibition controls. The corrected report marks those metrics not applicable for A; original synthetic artifacts and QA findings remain preserved. See the QA report for the complete regression and final verification record.
