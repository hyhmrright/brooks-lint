# Health tool workflow author stage

Diagnosis: the retained text-only retest could not invoke the existing score helper;
its revised health arm still produced conflicting headline totals. The helper's
legacy checker verified one block but did not bind final report bytes or enforce a
score-free draft. This is a workflow gap, not evidence of incorrect helper arithmetic.

Changes:
- `skills/brooks-health/SKILL.md`: require finalization/checking when tool execution is permitted.
- `skills/brooks-health/health-guide.md`: one ledger, score-free draft, deterministic insertion, checked artifact delivered unchanged; host tools supported.
- `skills/brooks-health/score-ledger.md`: CLI and host contract, receipts, failure semantics and limitations.
- `skills/brooks-health/scripts/score-dashboard.mjs`: exported `finalizeDashboard`, `verifyDashboard`, `SCORE_PLACEHOLDER`; CLI finalize/check-report; unchanged legacy render/check.
- `scripts/health-dashboard.test.mjs`: unique-total, stale ledger, tampering, placeholders, unknown dimensions, CLI preservation/no overwrite and ordinary prose regressions.

No new risks, step renumbering, descriptions or trigger boundaries changed. No historical results edited. No live model calls. `node --test scripts/health-dashboard.test.mjs`: 10/10 PASS.

Host integration: accept `{ledger,draft}`; call `finalizeDashboard(ledger,draft)` -> report; `verifyDashboard(ledger,report)` -> receipt. Explicitly include `score-ledger.md` with candidate guide in tool-enabled benchmark; do not assume an older prompt assembler includes it. SHA ledger binding uses JSON.stringify(parsed ledger); report binding uses exact UTF-8 report bytes. Semantic diagnosis and arbitrary score paraphrases remain outside verifier coverage.
