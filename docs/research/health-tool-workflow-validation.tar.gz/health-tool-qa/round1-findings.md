# Health tool workflow QA — round 1

Verdict: FAIL (report metric semantics; routed to eval-curator).

`evals/research/health-tool-retest/report.mjs:9` (pre-fix) counted A-arm AS-25 prohibited cases in the denominator, but counted passing cases through `workflowPassed`. `tool.mjs:20` returns null for every A-arm workflow result. The retained simulation therefore represented three clean no-tool A controls as `prohibited: 3, prohibitedPassed: 0`. This would mislead comparison readers. A's tool-enabled workflow metrics must be explicitly not applicable, or the prohibition success must be calculated independently for both arms.

The author/eval freeze at the start of this round was `8cfc2f46a1f588a34d8e66188be2a496a018806c413458de21a659dda3e4876a`. The metric fix was applied during the initial npm test run; this round cannot be the final immutable-source gate. A full second gate is required after refreezing and regenerating retained simulation evidence.

Other checks completed before loopback: repository validation; version crosschecks (1.9.1 across four manifests, six README badges, JSON-LD and CHANGELOG); twelve-source inventory and README/AGENTS/GEMINI claims; 64 structural scenarios; six skill negative trigger boundaries; initial frozen snapshot validation; byte-identical reproduction of the retained 48-row simulated report; real CLI 0.167.1 local wire source/receipt/final-answer/cleanup verification; prior result SHA checks. No real model calls. Heuristic credential-pattern scan found no matches in 251 retained evidence files.

Preserve all logs in this directory as the first-round record. See the subsequent round for final status.

Initial `npm test` completed with exit 0, including the new 17/17 health-tool cases. Because the metric source fix landed during this run, it is retained as interim verification only.
