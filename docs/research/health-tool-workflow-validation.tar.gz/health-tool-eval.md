# Health tool retest eval stage

PASS (targeted). No live model calls.

- New separate health-tool-retest adapter, runner, tool, reporter, fake CLI and tests.
- Freeze: 8 cases × 2 arms × 3 repeats = 48 primary turns. A previous revised text-only guidance; B current guide + ledger docs + host finalizer. Same-workflow known cases; not an isolated prompt effect or independent holdout study.
- Anchor: 8cfc2f46a1f588a34d8e66188be2a496a018806c413458de21a659dda3e4876a.
- Limits: 300 seconds/turn, 4 hours, 2M observed token admission, no failed-turn retries, max4 tool calls/turn; all fail/unknown-usage stop behavior retained.
- Targeted suite 17/17 passes with OS process inspection permission. Initial sandbox invocation failed because process-group observation is unavailable; no guard bypassed. Two local implementation corrections (import depth, duplicate test variable) were fixed before passing.
- Preserved full synthetic drill: `_workspace/brooks-harness/health-tool-eval/drill/`, 48 raw responses, 48 explicitly synthetic reviews, 24 pairs and report.
- Preserved actual CLI 0.167.1/local fake-upstream wire drill: `_workspace/brooks-harness/health-tool-eval/wire/`, 2 authored HTTP responses, 1 scoring call, exact final artifact, confirmed cleanup. No auth or real upstream. Earlier parent wire proof retained separately.
- `npm run evals`: 64/64 structural cases valid. No risk code changes; historic evals/results/freezes unchanged.
- Added npm `evals:health-tool` to npm test.
- New final collector uses completed final_answer when present, otherwise all completed; raw all-phase messages and supplemental masked review evidence retained. No pooling with historical studies.
- Live handoff recipe in docs/research/health-tool-retest.md; no registration/live approval yet.

## QA loopback

QA found A's non-applicable tool controls were aggregated as 0/3. Fixed aggregate
A tool metrics to `applicable:false`, null denominators/pass counts, with observed
call counts preserved. B remains applicable and its out-of-scope control passes3/3
in the synthetic drill. Added assertions to the full-study regression. This is
metric plumbing, not a model-outcome correction.

Final anchor: e3ba494a7fdff3b1636f43b99b8e6b9f5203c1c558fe1bff292bbdce72135cf7.
Targeted tests17/17 PASS. Fresh full synthetic evidence: `health-tool-eval/round2-drill/`;
fresh actual CLI/local upstream: `health-tool-eval/round2-wire/`,2HTTP responses,
1host call, exact final and confirmed cleanup. Original pre-QA artifacts and
`pre-qa-frozen-full.json` preserved. No real model calls.
