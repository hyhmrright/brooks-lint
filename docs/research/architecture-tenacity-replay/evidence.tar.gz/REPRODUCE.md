# Replay Tenacity's wrapper case

Unpack this bundle in an empty writable directory. The check commands used
CPython 3.11.18, Git and the listed tool freezes. No model access is needed to
verify the original patches.

```sh
shasum -a 256 -c SHA256SUMS
shasum -a 256 -c PROTOCOL.sha256
bash prepare-snapshots.sh
python3.11 -m venv venv-tenacity
venv-tenacity/bin/python -m pip install -r tenacity.freeze
mkdir base
tar -xzf tenacity-base.tgz -C base
for variant in base upstream checklist audit-before audit-after; do
  bash verify.sh "$variant"
done
for variant in checklist audit-before audit-after; do
  python3 assess.py "$variant"
done
python3 admit_positive.py admission.json
```

The original candidate patches are under `results-proxy/tenacity`. Per-arm
checks are under `verification/<variant>/logs` after replay. The compatible
Ruff check used a second environment with `ruff==0.15.7`; run `ruff check .`
from each verified tree. The original 0.16.8 reports contain inherited
`RUF036` diagnostics. Authored tests are bound to a 10-second evaluator
deadline. Under the mutation the expected exit values are checklist 0,
previous audit 1, revised audit 124. Recheck the copy-limited diagnostic
separately by applying `diagnostic/limit-retries.patch` in a disposable copy
of the revised tree. The original review verdict excludes that diagnostic.

For documentation, clone the upstream project as `docs-history`. Build a
wheel from a separate copy of the archived base with
`SETUPTOOLS_SCM_PRETEND_VERSION=9.1.4 uv build --wheel --out-dir wheel <base-copy>`.
Create a Python 3.11.18 environment at `venv-tenacity-docs`, install
`docs-dependencies.freeze` and that wheel, then invoke `bash verify-docs.sh`
once per variant. It creates detached worktrees at the intended revisions,
applies the unchanged candidate patch, and runs both upstream Sphinx
builders. This separate environment supplies package metadata while
`PYTHONPATH` ensures Sphinx imports source from the checked-out worktree.

To verify the admitted source defect, run `protocol/mutate.py` in a fresh
base tree, then run its full pytest and the independent probe with that
tree on `PYTHONPATH`. The probe hits the override-marker assertion while
the suite passes. The receipts also show why the earlier controller-reuse
defect did not meet admission.
