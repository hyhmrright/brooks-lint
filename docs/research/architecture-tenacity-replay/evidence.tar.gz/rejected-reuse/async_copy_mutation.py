"""Apply the copy-loss challenge without depending on an internal helper name."""
from functools import wraps

from tenacity import AsyncRetrying

original_copy = AsyncRetrying.copy


@wraps(original_copy)
def reuse_for_invocation(self, *args, **kwargs):
    if not args and not kwargs:
        return self
    return original_copy(self, *args, **kwargs)


AsyncRetrying.copy = reuse_for_invocation
