"""Collapse async wrapper invocation copies into the template controller."""
from pathlib import Path

path = Path("tenacity/asyncio/__init__.py")
source = path.read_text()
old = "            copy = self.copy()"
assert source.count(old) == 1
path.write_text(source.replace(old, "            copy = self", 1))
