#!/usr/bin/env bash
# Verify one exact patch or upstream snapshot with its project-specific environment.
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
project="$1"
variant="$2"
run_root="$root/verification/$project/$variant"
tree="$run_root/tree"
logs="$run_root/logs"
mkdir -p "$logs"
mkdir "$tree"
archive="$root/$project-base.tgz"
if [ "$variant" = upstream ]; then archive="$root/$project-upstream.tgz"; fi
tar -xzf "$archive" -C "$tree"
cd "$tree"
export PATH="$root/pyright-node/node_modules/.bin:$root/venv-$project/bin:$PATH"
export VIRTUAL_ENV="$root/venv-$project"
export PYTHONPATH="$tree/src:$tree" PYTHONDONTWRITEBYTECODE=1 CI=1
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null
if [ "$project" = attrs ]; then export MYPYPATH="$tree/src"; fi
record() {
  local name="$1"
  shift
  local status=0
  {
    printf '%q ' "$@"
    printf '\n'
    "$@"
  } > "$logs/$name.log" 2>&1 || status="$?"
  printf '%s\t%s\n' "$name" "$status" >> "$logs/status.tsv"
  printf '\nEXIT %s\n' "$status" >> "$logs/$name.log"
  return "$status"
}
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  patch="$root/${REPLAY_OUTPUT:-results-proxy}/$project/$variant/candidate.patch"
  if [ ! -s "$patch" ]; then
    printf 'empty-patch\t1\n' >> "$logs/status.tsv"
    exit 1
  fi
  record apply-check git apply --check "$patch"
  record apply git apply "$patch"
fi
git init -q
git add -f .
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  git apply --numstat "$patch" | cut -f3 > "$logs/changed-files.txt"
  python "$root/syntax.py" "$logs/changed-files.txt" > "$logs/syntax.log" 2>&1 && syntax=0 || syntax="$?"
  printf 'syntax\t%s\n' "$syntax" >> "$logs/status.tsv"
fi
record probe python "$root/protocol/$project-probe.py" || true
if [ "${STATIC_ONLY:-}" != "1" ]; then
  record suite python -m pytest -q -p no:cacheprovider || true
fi
case "$project" in
  attrs)
    record mypy-example mypy tests/typing_example.py || true
    record mypy-stubs mypy src/attrs/__init__.pyi src/attr/__init__.pyi src/attr/_typing_compat.pyi src/attr/_version_info.pyi src/attr/converters.pyi src/attr/exceptions.pyi src/attr/filters.pyi src/attr/setters.pyi src/attr/validators.pyi || true
    record ruff ruff check . || true
    record ruff-format ruff format --check . || true
    record interrogate interrogate tests || true
    record codespell codespell --exclude-file=tests/test_mypy.yml . || true
    record trailing-whitespace python "$root/attrs_hooks.py" trailing-whitespace-fixer || true
    record end-of-file python "$root/attrs_hooks.py" end-of-file-fixer || true
    record check-toml python "$root/attrs_hooks.py" check-toml || true
    record check-yaml python "$root/attrs_hooks.py" check-yaml || true
    ;;
  cattrs)
    record flake8 flake8 src/ tests || true
    record black black --check src tests docs/conf.py || true
    ;;
  httpcore)
    record isort isort --check --diff --project=httpcore httpcore tests || true
    record black black --exclude '/(_sync|sync_tests)/' --check --diff --target-version=py37 httpcore tests || true
    record flake8 flake8 httpcore tests || true
    record mypy mypy httpcore tests || true
    record unasync scripts/unasync --check || true
    ;;
esac
record verify-no-modifications git diff --exit-code || true
