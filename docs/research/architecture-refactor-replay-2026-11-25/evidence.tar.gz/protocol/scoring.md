# Scoring fixed before generation

One row per evidence cluster. Credit only an explicit source-backed trace in the
answer or an executable candidate test that checks the behavior through the
stated entry point. Mark those as separate evidence. Existing upstream tests
count only if the candidate identifies them and articulates which contract they
verify. A decision changes the first cut only when it changes the production
scope or compatibility mechanism relative to another arm and cites the constraint.
A distinction in authored tests alone is reported as a difference in coverage.
Independently apply and verify exact patches without edits. Include base and
mutation-control runs. A deliberate mutation is a test-sensitivity control, never
a submitted patch. Record timeout, baseline failure, and infrastructure limits.
One run per arm and case is a pilot.

- attrs A1: trace define and make_class into attr.s and the class builder.
- attrs A2: both generated initializer variants, including init=False and the
  user __init__ that delegates through __attrs_init__.
- attrs A3: actual instance dispatch to pre/post-init hooks, including inherited
  or overridden hooks; preserve alias/annotation/dunder or generated globals.
- cattrs C1: registered predicate/factory order, exception tolerance, and
  lookup precedence over the fallback.
- cattrs C2: structure missing-handler error and unstructure identity fallback;
  keep the bare FunctionDispatch miss behavior in the preparation patch.
- cattrs C3: re-registration invalidates resolution; copy behavior differs between
  singledispatch and predicate entries, and fallback placement and skip counts
  constrain positional copy behavior.
- httpcore H1: explicit and context-manager shutdown dispatch, generated sync
  parity, and public subclass behavior through normal exit.
- httpcore H2: capture active request count, close connections and reset pool
  state before raising the existing policy error.
- httpcore H3: stream finalization after shutdown and pool reuse; document the
  distinct coordination/ownership paths.
