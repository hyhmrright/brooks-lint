import anyio
from httpcore import AsyncConnectionPool, ConnectionPool
from httpcore.backends.mock import AsyncMockBackend, MockBackend

URL = "http://example.com/"
RESPONSE = [
    b"HTTP/1.1 200 OK\r\nContent-Length: 1\r\n\r\n",
    b"x",
]


class Pool(ConnectionPool):
    close_calls = 0

    def close(self):
        self.close_calls += 1
        return super().close()


class AsyncPool(AsyncConnectionPool):
    close_calls = 0

    async def aclose(self):
        self.close_calls += 1
        return await super().aclose()


def verify_error(close):
    try:
        close()
    except RuntimeError as exc:
        assert "1 HTTP requests/responses were still in-flight" in str(exc)
    else:
        raise AssertionError("active pool close must raise")


with Pool(network_backend=MockBackend(RESPONSE)) as pool:
    with pool.stream("GET", URL):
        verify_error(pool.close)
        assert pool.connections == []
    with pool.stream("GET", URL) as response:
        assert response.read() == b"x"
assert pool.close_calls == 2


async def main():
    async with AsyncPool(network_backend=AsyncMockBackend(RESPONSE)) as pool:
        async with pool.stream("GET", URL):
            try:
                await pool.aclose()
            except RuntimeError as exc:
                assert "1 HTTP requests/responses were still in-flight" in str(exc)
            else:
                raise AssertionError("active async pool close must raise")
            assert pool.connections == []
        async with pool.stream("GET", URL) as response:
            assert await response.aread() == b"x"
    assert pool.close_calls == 2


anyio.run(main, backend="asyncio")
anyio.run(main, backend="trio")
print("explicit/context close, stream ownership, and reuse passed")
