from attrs import define
from cattrs import Converter
from cattrs.dispatch import FunctionDispatch
from cattrs.errors import StructureHandlerNotFoundError


class Unknown:
    pass


@define
class Wrapped:
    value: int


for dispatch in (FunctionDispatch().dispatch, lambda typ: Converter().structure("x", typ)):
    try:
        dispatch(Unknown)
    except StructureHandlerNotFoundError as exc:
        assert exc.type_ is Unknown
    else:
        raise AssertionError("miss did not raise the expected exception")


def broken_predicate(_):
    raise ValueError("predicate cannot handle this type")


converter = Converter()
assert converter.structure({"value": 1}, Wrapped).value == 1
converter.register_structure_hook_func(lambda t: t is Wrapped, lambda data, _: Wrapped(data["value"] + 10))
converter.register_structure_hook_func(broken_predicate, lambda data, _: Wrapped(-1))
assert converter.structure({"value": 1}, Wrapped).value == 11
copied = converter.copy()
assert copied.structure({"value": 1}, Wrapped).value == 1
copied.register_structure_hook_factory(lambda t: t is Wrapped, lambda _t: lambda data, _: Wrapped(data["value"] + 20))
assert copied.structure({"value": 1}, Wrapped).value == 21
assert converter.structure({"value": 1}, Wrapped).value == 11

converter.register_structure_hook(Unknown, lambda data, _: ("class", data))
assert converter.copy().structure("x", Unknown) == ("class", "x")
converter.register_structure_hook_func(lambda t: t is Wrapped, lambda data, _: Wrapped(99))
assert copied.structure({"value": 1}, Wrapped).value == 21
assert converter.structure({"value": 1}, Wrapped).value == 99
marker = Unknown()
assert converter.unstructure(marker) is marker
print("predicates, registration/cache precedence, copies and asymmetric misses passed")
