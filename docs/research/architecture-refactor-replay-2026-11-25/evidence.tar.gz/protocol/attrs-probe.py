import inspect

import attr
import attrs

events = []


class Base:
    def __attrs_post_init__(self):
        events.append(("base", self.x))


@attrs.define(slots=True)
class Decorated(Base):
    x: int = attrs.field(converter=int)


def post_init(self):
    events.append(("factory", self.x))


def custom_init(self, value):
    self.__attrs_init__(value)


def pre_init(self, x):
    events.append(("pre", x))


Factory = attrs.make_class(
    "Factory", {"x": attr.ib(type=int, converter=int, alias="value")},
    bases=(Base,), slots=True, init=False,
    class_body={"__init__": custom_init, "__attrs_pre_init__": pre_init,
                "__attrs_post_init__": post_init},
)


class Override(Decorated):
    def __attrs_post_init__(self):
        events.append(("override", self.x))


assert Decorated("4").x == 4
assert Override("5").x == 5
assert Factory("6").x == 6
assert Factory.__attrs_init__.__qualname__ == "Factory.__attrs_init__"
assert list(inspect.signature(Factory.__attrs_init__).parameters) == ["self", "value"]
assert events == [("base", 4), ("override", 5), ("pre", "6"), ("factory", 6)], events
print("decorator, subclass override, factory custom-init and generated signature passed")
