"""Inject one known behavior break per case to check probe sensitivity."""
import sys
from pathlib import Path


def replace_once(path, before, after):
    path = Path(path)
    source = path.read_text()
    assert source.count(before) == 1, path
    path.write_text(source.replace(before, after, 1))


project = sys.argv[1]
if project == "attrs":
    replace_once(
        "src/attr/_make.py",
        'lines.append("self.__attrs_post_init__()")',
        'lines.append("pass")',
    )
elif project == "cattrs":
    replace_once(
        "src/cattrs/dispatch.py",
        'self._handler_pairs.insert(0, (can_handle, func, is_generator))',
        'self._handler_pairs.append((can_handle, func, is_generator))',
    )
elif project == "httpcore":
    for kind, close, pool in (("_sync", "close", "ConnectionPool"), ("_async", "aclose", "AsyncConnectionPool")):
        await_ = "await " if kind == "_async" else ""
        replace_once(
            f"httpcore/{kind}/connection_pool.py",
            f"        {await_}self.{close}()\n\n\nclass ConnectionPoolByteStream:",
            f"        {await_}{pool}.{close}(self)\n\n\nclass ConnectionPoolByteStream:",
        )
else:
    raise SystemExit(f"unknown case {project}")
