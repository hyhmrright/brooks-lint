"""Run the pinned generic attrs hooks on their configured file types."""
from pathlib import Path
import subprocess
import sys

from identify.identify import tags_from_path


args = {
    "trailing-whitespace-fixer": "text",
    "end-of-file-fixer": "text",
    "check-toml": "toml",
    "check-yaml": "yaml",
}
command = sys.argv[1]
files = subprocess.check_output(["git", "ls-files", "-z"]).decode().split("\0")
eligible = [
    name for name in files
    if name and Path(name).exists() and args[command] in tags_from_path(name)
]
raise SystemExit(subprocess.call([command, *eligible]))
