# Reproduce the independent architecture replay

Extract the evidence bundle into a writable scratch location. The candidate
patches are unchanged. To re-create the upstream archives, run the snapshot
script in this directory with GitHub access. The optional full local copy
already has the six archives.

```sh
shasum -a 256 -c SHA256SUMS
bash prepare-snapshots.sh
for project in attrs cattrs httpcore; do
  python3.11 -m venv "venv-$project"
  "venv-$project/bin/python" -m pip install -r "$project.freeze"
done
npm install --prefix pyright-node --no-audit --no-fund pyright@1.1.394
for project in attrs cattrs httpcore; do
  for variant in base upstream checklist audit-before audit-after; do
    bash verify.sh "$project" "$variant"
  done
done
```

The reference interpreter is CPython 3.11.18 on macOS ARM64. Use one
previously empty `verification/` directory for each replay. HTTP Core uses
local HTTP and TLS fixtures, and Black can need a local multiprocessing socket.
Each `verification/<project>/<variant>/logs/status.tsv` contains the actual
exit code of every check. The historical cattrs and HTTP Core probes are
expected to exit 1 because they assert the pre-change policy. A probe failure on
a candidate is a regression. The mutation controls are described in
`protocol/scoring.md` and executed by applying `protocol/mutate.py` in a disposable
base tree, then invoking the corresponding probe with the same environment.

`receipts/` contains the original check logs. The formal Codex CLI inputs and
outputs are under `results-proxy/`. The optional local archive also contains
raw event JSONL and an interrupted direct-transport diagnostic for audit.
The formal `run.json` receipts record observed wall times; the event transport
timestamps and account-local identifiers are unnecessary to verify patches.
