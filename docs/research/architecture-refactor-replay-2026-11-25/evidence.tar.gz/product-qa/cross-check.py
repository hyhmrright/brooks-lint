import json
import re
import subprocess
from pathlib import Path

def load(name):
    return json.loads(Path(name).read_text())

def check(path, label, actual, expected):
    assert actual == expected, f"{path} {label}: expected {expected!r}, got {actual!r}"
    print(f"{path} {label}: {actual}")

package = load("package.json")["version"]
for manifest in (".claude-plugin/plugin.json", ".codex-plugin/plugin.json", "gemini-extension.json"):
    check(manifest, "version", load(manifest)["version"], package)
marketplace = ".claude-plugin/marketplace.json"
plugin, = (entry for entry in load(marketplace)["plugins"] if entry["name"] == "brooks-lint")
check(marketplace, "brooks-lint version", plugin["version"], package)
readmes = sorted(Path.cwd().glob("README*.md"))
check("README*.md", "badge file count", len(readmes), 6)
for readme in readmes:
    badge, = re.findall(r"img\.shields\.io/badge/version-([\d.]+)-", readme.read_text())
    check(readme.name, "badge version", badge, package)
landing = "docs/index.html"
json_ld, = re.findall(r'<script type="application/ld\+json">\s*(.+?)\s*</script>', Path(landing).read_text(), re.S)
check(landing, "JSON-LD softwareVersion", json.loads(json_ld)["softwareVersion"], package)
changelog = "CHANGELOG.md"
versions = re.findall(r"^## \[([\d.]+)\]", Path(changelog).read_text(), re.M)
check(changelog, "first versioned section", versions[0], package)
book_source = "skills/_shared/source-coverage.md"
books = re.findall(r"^  - (.+)$", Path(book_source).read_text().split("---", 2)[1], re.M)
number_words = tuple("zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty".split())
print(f"{book_source} derived book count: {len(books)}")
for document in ("README.md", "AGENTS.md", "GEMINI.md"):
    count, = re.findall(r"\b(\w+) classic engineering books", Path(document).read_text())
    check(document, "book count word", count, number_words[len(books)])
expected_evals = len(load("evals/evals.json")["evals"])
eval_claims = re.findall(r"(\d+) (?:benchmark )?scenarios", Path("AGENTS.md").read_text())
for claim in eval_claims:
    check("AGENTS.md", "scenario count", int(claim), expected_evals)
assert eval_claims
skills = sorted(Path("skills").glob("*/SKILL.md"))
check("skills", "skill count", len(skills), 6)
for skill in skills:
    frontmatter = skill.read_text().split("---", 2)[1]
    description, = re.findall(r"^description: (.*(?:\n +.+)*)", frontmatter, re.M)
    check(skill.as_posix(), "negative boundary at description end", bool(re.search(r"Do NOT trigger for:\s*\S.+$", " ".join(description.split()))), True)
wrappers = subprocess.check_output(["git", "ls-files", "commands/*"], text=True).splitlines()
check("commands", "wrapper inventory", sorted(wrappers), sorted(f"commands/{skill.parent.name}.md" for skill in skills))
diff = subprocess.check_output(["git", "diff", "HEAD", "--name-only"], text=True).splitlines()
check("git diff HEAD", "changed files", diff, ["skills/brooks-audit/architecture-guide.md"])
