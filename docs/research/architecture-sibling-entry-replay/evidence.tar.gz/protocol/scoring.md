# Frozen scoring rules

The candidate sees the task and assigned guidance. The evaluator judges only
the final answer, exact patch and independently replayed results. A trace
requires citations to the selection or delegation code. Test credit requires an
assertion on the affected behavior through the real route.

Positive (cachetools)
- P1: map instance lookup and class invocation through _Unbound to bound
  wrappers. Attribute these to their public entry points.
- P2: trace the subclass/override and super lookup to distinct wrappers and
  explain why reusing or recreating the wrong wrapper changes behavior.
- P3: preserve per-instance wrapper and cache/statistics ownership.
- P4: count an incremental design decision only if a route changes the source
  seam, or a new test through a distinct public route kills the corresponding
  deliberate mutation that other arms' authored tests miss. Existing test
  sensitivity is measured separately.

Equivalent-entry control (platformdirs)
- C1: trace iter_config_paths through iter_config_dirs and the backend before
  converting to Path. Both entry points share config selection, ordering,
  deduplication and directory creation.
- C2: preserve Unix site redirection and shared iteration behavior. Either
  public entry can protect the shared policy. Output-type and special backend
  checks are separately justified if the production cut affects them.
- C3: count redundant regressions only when a candidate adds duplicate checks
  for the same shared behavior through both the string and Path adapter with
  no separate assertion on either adapter's contract.

Decision: an incremental benefit requires a source seam attributable to a
verified distinct route, or an original candidate test that kills a deliberate
behavior break missed by both comparators. Also record whether the base suite
already catches that break. Shrink the guidance if the equivalent-entry control
adds unjustified duplicate checks. Record one run per arm per case as a pilot.
