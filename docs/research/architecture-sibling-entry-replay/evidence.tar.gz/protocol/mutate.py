"""Replace one known behavior in a disposable fixture with a deliberate defect."""
from pathlib import Path
import sys

replacements = {
    ("cachetools", "unbound"): (
        "src/cachetools/_descriptor.py",
        "return self.__descriptor.__get__(obj)(*args, **kwargs)",
        "return self.__wrapped__(obj, *args, **kwargs)",
    ),
    ("cachetools", "super"): (
        "src/cachetools/_descriptor.py",
        'wrappers = obj.__dict__.setdefault("__cachetools_cachedmethods", {})',
        'wrappers = {}',
    ),
    ("platformdirs", "duplicates"): (
        "src/platformdirs/api.py",
        "yield from _unique(self._iter_config_dirs())",
        "yield from self._iter_config_dirs()",
    ),
}
filename, before, after = replacements[tuple(sys.argv[1:])]
path = Path(filename)
source = path.read_text()
if source.count(before) != 1:
    raise SystemExit(2)
path.write_text(source.replace(before, after, 1))
