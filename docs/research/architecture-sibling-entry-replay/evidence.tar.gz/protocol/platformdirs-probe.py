import os
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from platformdirs.unix import Unix


with TemporaryDirectory() as directory:
    root = Path(directory)
    user = root / "user"
    site = root / "site"
    env = {"XDG_CONFIG_HOME": str(user), "XDG_CONFIG_DIRS": os.pathsep.join(map(str, (user, site, site)))}
    with patch.dict(os.environ, env):
        options = {"appname": "probe", "ensure_exists": True}
        for constructor, expected in (
            (lambda: Unix(**options), (user / "probe", site / "probe")),
            (lambda: Unix(**options, use_site_for_root=True), (user / "probe", site / "probe")),
        ):
            with patch("os.geteuid", return_value=0):
                instance = constructor()
                actual = list(instance.iter_config_paths())
                assert tuple(actual) == expected, actual
                assert all(path.is_dir() for path in actual)
                assert tuple(instance.iter_config_dirs()) == tuple(map(str, actual))
print("config order, deduplication, directory creation and Path adapters passed")
