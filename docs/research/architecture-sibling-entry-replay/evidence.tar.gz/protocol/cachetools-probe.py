from cachetools import cachedmethod


class Base:
    def __init__(self, label):
        self.label = label
        self.base_cache = {}
        self.override_cache = {}
        self.calls = []

    @cachedmethod(lambda self: self.base_cache, key=lambda self, key: key, info=True)
    def lookup(self, key):
        self.calls.append(("base", key))
        return ("base", self.label, key)


class Child(Base):
    @cachedmethod(lambda self: self.override_cache, key=lambda self, key: key, info=True)
    def lookup(self, key):
        self.calls.append(("child", key))
        return ("child", super().lookup(key))


def main():
    item = Child("first")
    other = Child("other")
    assert item.lookup(3) == ("child", ("base", "first", 3))
    assert Base.lookup(item, 3) == ("base", "first", 3)
    assert Child.lookup(self=item, key=3) == ("child", ("base", "first", 3))
    assert super(Child, item).lookup(3) == ("base", "first", 3)
    assert item.calls == [("child", 3), ("base", 3)]
    assert item.lookup.cache_info().hits == 1
    assert super(Child, item).lookup.cache_info().hits == 2

    assert Child.lookup(other, 3) == ("child", ("base", "other", 3))
    assert other.calls == [("child", 3), ("base", 3)]
    assert item.calls == [("child", 3), ("base", 3)]
    super(Child, item).lookup.cache_clear()
    assert item.lookup(3) == ("child", ("base", "first", 3))
    assert Base.lookup(item, 3) == ("base", "first", 3)
    assert item.calls[-1] == ("base", 3) and len(item.calls) == 3
    print("bound, class positional/keyword, super, per-instance state and clear passed")


if __name__ == "__main__":
    main()
