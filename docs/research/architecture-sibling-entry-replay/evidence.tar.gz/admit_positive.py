"""Check whether a prospective case can measure new mutation sensitivity."""
import argparse
import json
from pathlib import Path


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("baseline_receipt", type=Path, help="base result.json from assess_mutants.py")
parser.add_argument("mutations", nargs="*", help="target mutation names; default is every recorded mutation")
options = parser.parse_args()
records = json.loads(options.baseline_receipt.read_text())
by_name = {record["mutation"]: record for record in records}
names = options.mutations or list(by_name)
if not names or set(names).difference(by_name):
    parser.error("specify recorded mutation names")

eligible = []
for name in names:
    result = by_name[name]
    if not result.get("pristine_pass"):
        outcome = "invalid: pristine baseline suite and probe must pass"
    elif result["injection_exit"] != 0 or result.get("probe_exit") != 1 or not result.get("probe_assertion"):
        outcome = "invalid: mutation must apply and trigger an independent probe assertion"
    elif result.get("base_suite_exit") == 0:
        eligible.append(name)
        outcome = "eligible: base suite passed despite the independently detected mutation"
    elif result.get("base_suite_exit") == 1:
        outcome = "covered: existing suite already detects this mutation"
    else:
        outcome = "invalid: base suite did not return a normal test verdict"
    print(f"{name}: {outcome}")
raise SystemExit(0 if eligible else 1)
