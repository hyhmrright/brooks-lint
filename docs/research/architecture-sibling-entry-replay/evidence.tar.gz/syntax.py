"""Compile changed Python sources without writing bytecode."""
import sys
from pathlib import Path

for entry in Path(sys.argv[1]).read_text().splitlines():
    path = Path(entry)
    if path.suffix == ".py" and path.is_file():
        compile(path.read_bytes(), str(path), "exec")
        print(path)
