"""Measure whether inherited and candidate-authored tests detect frozen defects."""
import ast
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MUTANTS = {"cachetools": ("unbound", "super"), "platformdirs": ("duplicates",)}


def functions(directory):
    def visit(nodes, parents=()):
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                yield from visit(node.body, (*parents, node.name))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                yield "::".join((*parents, node.name)), ast.dump(node)

    return {
        f"{file.relative_to(directory)}::{name}": body
        for file in (directory / "tests").rglob("test_*.py")
        for name, body in visit(ast.parse(file.read_bytes()).body)
    }


def execute(args, tree, env, log):
    with log.open("wb") as output:
        return subprocess.run(args, cwd=tree, env=env, stdout=output, stderr=subprocess.STDOUT).returncode


def measure(project, arm):
    verification = ROOT / ("verification-314" if project == "cachetools" else "verification") / project
    venv = ROOT / ("venv-cachetools-314" if project == "cachetools" else "venv-platformdirs")
    source = verification / arm / "tree"
    original = functions(verification / "base" / "tree")
    candidate = functions(source)
    changed = {name for name, body in candidate.items() if original.get(name) != body}

    def leaf(node):
        return (node.split("::", 1)[0], node.split("::")[-1])

    # Pytest collects inherited mixin methods under the concrete test class.
    # Resolve that case only when the source test name is unique in its file.
    from collections import Counter

    counts = Counter(leaf(name) for name in candidate)
    inherited = {leaf(name) for name in changed if counts[leaf(name)] == 1}
    logs = verification / arm / "logs"
    nodes = [
        line.strip() for line in (logs / "collected.log").read_text().splitlines()
        if line.startswith("tests/") and (
            line.partition("[")[0] in changed or leaf(line.partition("[")[0]) in inherited
        )
    ]
    receipts = dict(line.split("\t") for line in (logs / "status.tsv").read_text().splitlines())
    pristine_pass = receipts.get("probe") == "0" and receipts.get("suite") == "0"
    summary = []
    for mutant in MUTANTS[project]:
        results = ROOT / "mutation-results" / project / arm / mutant
        results.mkdir(parents=True, exist_ok=True)
        tree = results / "tree"
        shutil.copytree(source, tree, ignore=shutil.ignore_patterns(".git", "__pycache__", ".ruff_cache", ".pytest_cache"))
        env = dict(os.environ, PYTHONPATH=f"{tree}/src:{tree}", PYTHONDONTWRITEBYTECODE="1")
        python = str(venv / "bin/python")
        mutation_rc = execute([python, str(ROOT / "protocol/mutate.py"), project, mutant],
                              tree, env, results / "injection.log")
        result = {"mutation": mutant, "injection_exit": mutation_rc, "selected_nodes": nodes,
                  "pristine_pass": pristine_pass}
        if mutation_rc == 0:
            result["probe_exit"] = execute(
                [python, str(ROOT / f"protocol/{project}-probe.py")], tree, env, results / "probe.log"
            )
            result["probe_assertion"] = any(
                line.startswith("AssertionError")
                for line in (results / "probe.log").read_text().splitlines()
            )
            target = [python, "-m", "pytest", "-q", "-p", "no:cacheprovider"]
            if arm == "base":
                result["base_suite_exit"] = execute(
                    [*target, "tests"], tree, env, results / "inherited-tests.log"
                )
            elif nodes:
                result["authored_tests_exit"] = execute(
                    [*target, *nodes], tree, env, results / "authored-tests.log"
                )
        summary.append(result)
    (ROOT / "mutation-results" / project / arm / "result.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )


measure(*sys.argv[1:])
