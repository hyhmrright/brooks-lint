# Replay the sibling-entry study

Unpack this bundle into a writable scratch directory. Run these commands on a
machine with GitHub access, CPython 3.11.18 and 3.14.10, Git and Node. The full
local dossier includes the archives already. The source archive script skips
existing archive pairs.

```sh
shasum -a 256 -c SHA256SUMS
shasum -a 256 -c PROTOCOL.sha256
bash prepare-snapshots.sh
for project in cachetools platformdirs; do
  python3.11 -m venv "venv-$project"
  "venv-$project/bin/python" -m pip install -r "$project.freeze"
done
python3.14 -m venv venv-cachetools-314
venv-cachetools-314/bin/python -m pip install -r cachetools-314.freeze
npm install --prefix pyright-node --no-audit --no-fund pyright@1.1.407
for variant in base upstream checklist audit-before audit-after; do
  bash verify.sh cachetools "$variant"
  REPLAY_VERIFY_DIR=verification-314 REPLAY_VENV="$PWD/venv-cachetools-314" \
    bash verify.sh cachetools "$variant"
  bash verify.sh platformdirs "$variant"
  bash precommit314.sh "$variant"
done
for project in cachetools platformdirs; do
  for variant in base checklist audit-before audit-after; do
    python3 assess_mutants.py "$project" "$variant"
  done
done
python3 admit_positive.py mutation-results/cachetools/base/result.json
```

The last command returns 1 for the archived cachetools case because both
mutations are already caught by the base suite. The synthetic admission
receipt demonstrates exit 0. Each replay requires fresh output directories.
Actual exit codes are in `status.tsv`, `status.txt` or the mutation JSON
receipts, and can include inherited failures documented in the study.
Pre-commit initializes pinned upstream hook environments on first use and
executes in a disposable tree. There were no modifications by hooks in the
formal replays. Original check receipts are under `receipts`.
