#!/usr/bin/env bash
# Replay the exact patch on a fresh copy, then check the source without edits.
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
project="$1"
variant="$2"
run_root="$root/${REPLAY_VERIFY_DIR:-verification}/$project/$variant"
tree="$run_root/tree"
logs="$run_root/logs"
mkdir -p "$logs"
mkdir "$tree"
archive="$root/$project-base.tgz"
if [ "$variant" = upstream ]; then archive="$root/$project-upstream.tgz"; fi
tar -xzf "$archive" -C "$tree"
if [ "$project" = platformdirs ]; then
  cp "$root/support/platformdirs-version.py" "$tree/src/platformdirs/version.py"
fi
cd "$tree"
git init -q
export VIRTUAL_ENV="${REPLAY_VENV:-$root/venv-$project}"
export PATH="$root/pyright-node/node_modules/.bin:$VIRTUAL_ENV/bin:$PATH"
export PYTHONPATH="$tree/src:$tree" PYTHONDONTWRITEBYTECODE=1
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null
record() {
  local label="$1"
  shift
  local check_rc=0
  {
    printf '%q ' "$@"
    printf '\n'
    "$@"
  } > "$logs/$label.log" 2>&1 || check_rc="$?"
  printf '%s\t%s\n' "$label" "$check_rc" >> "$logs/status.tsv"
  printf '\nEXIT %s\n' "$check_rc" >> "$logs/$label.log"
  return "$check_rc"
}
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  patch="$root/results-proxy/$project/$variant/candidate.patch"
  test -s "$patch"
  record apply-check git apply --check "$patch"
  record apply git apply "$patch"
  git apply --numstat "$patch" | cut -f3 > "$logs/changed-files.txt"
  record syntax python "$root/syntax.py" "$logs/changed-files.txt" || true
fi
record probe python "$root/protocol/$project-probe.py" || true
record suite python -m pytest -q -p no:cacheprovider tests || true
record collected python -m pytest --collect-only -q -p no:cacheprovider tests || true
record ruff ruff check . || true
record ruff-format ruff format --check . || true
case "$project" in
  cachetools)
    record pyright pyright --pythonpath "$VIRTUAL_ENV/bin/python" || true
    ;;
  platformdirs)
    record ty ty check --output-format concise --error-on-warning . || true
    ;;
esac
