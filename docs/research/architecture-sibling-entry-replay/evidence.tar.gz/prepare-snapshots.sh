#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
while IFS=$'\t' read -r project url base upstream; do
  if [ -s "$project-base.tgz" ] && [ -s "$project-upstream.tgz" ]; then
    continue
  fi
  git clone --quiet --filter=blob:none --no-checkout "$url" "snapshot-$project"
  git -C "snapshot-$project" archive "$base" | gzip > "$project-base.tgz"
  git -C "snapshot-$project" archive "$upstream" | gzip > "$project-upstream.tgz"
done < sources.tsv
