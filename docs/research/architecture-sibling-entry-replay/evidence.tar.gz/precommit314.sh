#!/usr/bin/env bash
# Run historical fix hooks on a disposable tree and record any changes.
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
variant="$1"
tree="$root/precommit-314/$variant/tree"
logs="$root/precommit-314/$variant/logs"
mkdir -p "$logs"
mkdir "$tree"
archive="$root/platformdirs-base.tgz"
if [ "$variant" = upstream ]; then archive="$root/platformdirs-upstream.tgz"; fi
tar -xzf "$archive" -C "$tree"
cd "$tree"
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  git apply "$root/results-proxy/platformdirs/$variant/candidate.patch"
fi
export PATH="$root/venv-cachetools-314/bin:$PATH"
export PRE_COMMIT_HOME="$root/precommit-cache"
export UV_CACHE_DIR="$root/uv-cache"
export PIP_DEFAULT_TIMEOUT=20 PIP_RETRIES=1
export GIT_CONFIG_COUNT=2
export GIT_CONFIG_KEY_0=http.lowSpeedLimit GIT_CONFIG_VALUE_0=1
export GIT_CONFIG_KEY_1=http.lowSpeedTime GIT_CONFIG_VALUE_1=15
git init -q
git add -f .
rc=0
pre-commit run --all-files --show-diff-on-failure > "$logs/pre-commit.log" 2>&1 || rc="$?"
echo "$rc" > "$logs/status.txt"
git diff --binary > "$logs/hook-edits.patch"
