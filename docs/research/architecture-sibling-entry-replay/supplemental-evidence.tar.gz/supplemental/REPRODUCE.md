# Replay the admitted packaging case

Use CPython 3.11.18, Git, and a writable scratch directory. This bundle does
not require model calls to reproduce the exact-patch verification.

```sh
shasum -a 256 -c SHA256SUMS
shasum -a 256 -c PROTOCOL.sha256
bash prepare-snapshots.sh
python3.11 -m venv venv-packaging
venv-packaging/bin/python -m pip install -r packaging.freeze
mkdir base
tar -xzf packaging-base.tgz -C base
for variant in base upstream checklist audit-before audit-after; do
  bash verify.sh "$variant"
done
for variant in checklist audit-before audit-after; do
  python3 assess.py "$variant"
done
```

Read the verification tree's `logs/status.tsv` and `mutation-result.json`.
The pristine authored test is expected to pass and the same test under the
runtime mutation to exit 1. The project runs property tests separately from
its default pytest selection. The `verify.sh` script runs both selections.

To reproduce the source-mutant admission, unpack a second base tree, run
`protocol/mutate.py` from its root and rerun the independent probe and
project suites with that tree's `src` on `PYTHONPATH`. The independent probe
must hit its subtype assertion. Compare its receipts to `admission.json`.
The checked-in argument `python3 admit_positive.py admission.json` returns
exit 0. The source mutation and runtime wrapper are frozen together.

To repeat configured hooks, use `bash precommit.sh <variant>`. Our Go
dependency setup timed out in pre-commit. We ran the complete hook set with
`SKIP=actionlint`, then built and ran the same pinned actionlint separately
in each disposable hook tree. The exact equivalent command was
`GOBIN="$PWD/actionlint-built" go install github.com/rhysd/actionlint/cmd/actionlint@v1.7.12`.
Run that executable in `precommit-314/<variant>/tree` if separating the
hook. The output directory name comes from the shared wrapper adapted for
this case. All packaging commands ran on Python 3.11.18. The original
receipts are under `receipts/`.
