"""Replay the same subtype-loss behavior against newly authored tests."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
variant = sys.argv[1]
verification = root / "verification" / variant
tree = verification / "tree"
out = verification / "logs"
base = root / "base"


def test_functions(root_folder, filenames):
    def walk(nodes, classes=()):
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                yield from walk(node.body, (*classes, node.name))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                yield "::".join((*classes, node.name)), ast.dump(node)

    return {
        f"{file}::{name}": body
        for file in filenames if (root_folder / file).is_file()
        for name, body in walk(ast.parse((root_folder / file).read_bytes()).body)
    }


env = dict(os.environ, PYTHONPATH=f"{tree}/src:{tree}:{root}/protocol", PYTHONDONTWRITEBYTECODE="1")
python = str(root / "venv-packaging/bin/python")
with (out / "mutated-probe.log").open("wb") as log:
    probe = subprocess.run(
        [python, "-c", 'import subtype_mutation, runpy, sys; runpy.run_path(sys.argv[1],run_name="__main__")',
         str(root / "protocol/packaging-probe.py")],
        cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT,
    )
files = [
    line for line in (out / "changed-files.txt").read_text().splitlines()
    if line.startswith("tests/") and line.endswith(".py")
]
previous = test_functions(base, files)
selectors = [
    name for name, body in test_functions(tree, files).items()
    if previous.get(name) != body
]
result = {"probe_exit": probe.returncode, "authored_selectors": selectors}
if selectors:
    for mode, plugin in (("pristine", []), ("mutated", ["-p", "subtype_mutation"])):
        with (out / f"{mode}-authored.log").open("wb") as log:
            process = subprocess.run(
                [python, "-m", "pytest", "-q", "-p", "no:cacheprovider", *plugin, *selectors],
                cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT,
            )
        result[f"{mode}_authored_exit"] = process.returncode
(out / "mutation-result.json").write_text(json.dumps(result, indent=2) + "\n")
