#!/usr/bin/env bash
set -eu
root="$(cd "$(dirname "$0")" && pwd)"
variant="$1"
run="$root/verification/$variant"
tree="$run/tree"
logs="$run/logs"
mkdir -p "$logs"
mkdir "$tree"
archive="$root/packaging-base.tgz"
if [ "$variant" = upstream ]; then archive="$root/packaging-upstream.tgz"; fi
tar -xzf "$archive" -C "$tree"
cd "$tree"
git init -q
export PATH="$root/venv-packaging/bin:$PATH"
export PYTHONPATH="$tree/src:$tree" PYTHONDONTWRITEBYTECODE=1
export MYPYPATH="$tree/src"
record() {
  local name="$1"
  shift
  local check_rc=0
  {
    printf '%q ' "$@"
    printf '\n'
    "$@"
  } > "$logs/$name.log" 2>&1 || check_rc="$?"
  printf '%s\t%s\n' "$name" "$check_rc" >> "$logs/status.tsv"
  printf '\nEXIT %s\n' "$check_rc" >> "$logs/$name.log"
  return "$check_rc"
}
if [ "$variant" != base ] && [ "$variant" != upstream ]; then
  patch="$root/results-proxy/packaging/$variant/candidate.patch"
  test -s "$patch"
  record apply-check git apply --check "$patch"
  record apply git apply "$patch"
  git apply --numstat "$patch" | cut -f3 > "$logs/changed-files.txt"
  record syntax python "$root/syntax.py" "$logs/changed-files.txt" || true
fi
record probe python "$root/protocol/packaging-probe.py" || true
record suite python -m pytest -q -p no:cacheprovider tests || true
record property python -m pytest -q -m property -p no:cacheprovider tests || true
record ruff ruff check src tests || true
record ruff-format ruff format --check src tests || true
record mypy mypy src tests || true
