from pathlib import Path

path = Path("src/packaging/version.py")
source = path.read_text()
before = "new_version = self.__class__.__new__(self.__class__)"
after = "new_version = Version.__new__(Version)"
if source.count(before) != 1:
    raise SystemExit(2)
path.write_text(source.replace(before, after, 1))
