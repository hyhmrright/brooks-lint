from packaging.version import Version


class TaggedVersion(Version):
    __slots__ = ("allocation",)

    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        instance.allocation = object()
        return instance


from_text = TaggedVersion("1!2.0rc1+meta")
from_parts = TaggedVersion.from_parts(epoch=1, release=(2, 0), pre=("rc", 1), local="meta")
for original in (from_text, from_parts):
    assert type(original) is TaggedVersion
    assert original.__replace__() is original
    assert original.__replace__(release=(2, 0)) is original
    assert hash(original) == hash(Version("1!2.0rc1+meta"))
    changed = original.__replace__(release=(3, 0), local=None)
    assert type(changed) is TaggedVersion
    assert changed.allocation is not original.allocation
    assert str(changed) == "1!3.0rc1"
    assert hash(changed) == hash(Version("1!3.0rc1"))
    assert str(original) == "1!2.0rc1+meta"
print("constructor, from_parts, subtype allocation, no-op identity and cache reset passed")
