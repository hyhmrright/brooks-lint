# Supplemental distinct-entry case

This case was defined after the primary two-case pilot, then frozen separately
before any candidate generation. Admission requires a pristine passing base and
a subtype-loss mutation which the independent probe detects but the base suite
does not. The evaluator tracks through which public constructors and replacement
dispatches the actual subclass is allocated, whether a distinct allocation
contract affects the first production seam, and whether newly authored tests
kill the frozen mutation. A new test must execute the real class route and
observe the retained subclass. Plain field-value tests alone do not earn this
credit. The main decision threshold from the two-case study remains unchanged.

The frozen source mutation verifies admission. The runtime equivalent
`subtype_mutation.py` drops the subtype from the public replacement return
without relying on the candidate's internal layout. The independent probe
must detect both. Authored test subsets are scored against the runtime
equivalent so different extraction shapes get the same behavior challenge.
