"""Exercise the subtype-loss defect through the preserved public protocol."""
from functools import wraps

from packaging.version import Version

original_replace = Version.__replace__


@wraps(original_replace)
def replace_as_base(self, **kwargs):
    result = original_replace(self, **kwargs)
    if result is not self and type(result) is not Version:
        return Version(str(result))
    return result


Version.__replace__ = replace_as_base
