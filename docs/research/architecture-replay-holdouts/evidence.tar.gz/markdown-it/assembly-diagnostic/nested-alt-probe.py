"""Check caller-visible text with a custom renderer on nested image tokens."""
from markupsafe import Markup
from markdown_it import MarkdownIt
from markdown_it.renderer import RendererHTML


class MarkupAltRenderer(RendererHTML):
    def renderInlineAsText(self, tokens, options, env):
        if tokens and len(tokens) == 1 and tokens[0].content == "INNER":
            return Markup("inner")
        return super().renderInlineAsText(tokens, options, env)


parser = MarkdownIt(renderer_cls=MarkupAltRenderer)
source = "![left & ![INNER](inner) right &](outer)"
inline = parser.renderInline(source)
result = parser.render(source)
print(repr(inline))
print(repr(result))
assert inline == '<img src="outer" alt="left &amp;amp; inner right &amp;amp;" />'
assert result == f"<p>{inline}</p>\n"
