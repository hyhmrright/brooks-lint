"""Exercise custom render-rule result dispatch through both public entries."""
from markupsafe import Markup
from markdown_it import MarkdownIt


def plugin(md):
    def render_text(renderer, tokens, idx, options, env):
        return Markup(tokens[idx].content)

    md.add_render_rule("text", render_text)


md = MarkdownIt().use(plugin)
inline = md.renderInline("plain")
assert isinstance(inline, Markup), "inline fragment lost its result subtype"
assert inline == "plain"
block = md.render("plain")
assert isinstance(block, Markup), "block fragment lost its result subtype"
assert block == "&lt;p&gt;plain&lt;/p&gt;\n"
