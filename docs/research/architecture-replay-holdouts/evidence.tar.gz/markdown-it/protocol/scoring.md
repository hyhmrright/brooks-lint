Trace MarkdownIt.render and renderInline through renderer construction,
custom rule registration and default/inline dispatch. Account for
renderInlineAsText (e.g. image alt processing) if the proposed cut moves that
sibling. Preserve supported overrides and observed str-subclass composition
for the first step. The frozen production-only mutation uses the upstream
renderer hunk. Score authored test failures independently, only if baseline
pytest passes under the mutation and the public probe fails as expected.
If the official hunk cannot apply on a candidate, report nonapplicability
until a separate copy exhibits the same independently verified mutation.
