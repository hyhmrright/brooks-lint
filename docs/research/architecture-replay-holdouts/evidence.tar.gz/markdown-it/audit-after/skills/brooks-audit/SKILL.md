---
name: brooks-audit
description: >
  Architecture audit that maps module dependencies, checks layering integrity, and
  flags structural decay across a codebase, drawing on twelve classic engineering books.
  Triggers when: user asks to audit architecture, review folder/module structure,
  check for circular imports, understand how the codebase is organized, or asks
  "does this follow clean architecture?" or "why does everything depend on everything?".
  Also triggers for onboarding requests: "explain this codebase to a new developer"
  or "give me a codebase tour" (use onboarding mode).
  Do NOT trigger for: PR-level code review (use brooks-review) or line-level refactoring
  questions — this skill analyzes structural/module-level concerns, not individual functions.
metadata:
  opencode/slash: "true"
---

# Brooks-Lint — Architecture Audit

## Setup

Read in order:

1. `../_shared/common.md` — Iron Law, Project Config, Report Template, Health Score
2. `../_shared/source-coverage.md` — book coverage, exceptions, tradeoffs
3. `../_shared/decay-risks.md` — symptom definitions and source attributions
4. `architecture-guide.md` (this directory) — the audit framework

## Process

**Onboarding mode:** If the user asks for an onboarding report, codebase tour, or
"explain this codebase to a new developer", read `onboarding-guide.md` from this
directory and follow it instead of `architecture-guide.md`. This mode explains rather
than diagnoses — no Health Score, no Iron Law findings.

**Scope:** if the user did not specify files or a directory, apply Auto Scope Detection
(`../_shared/common.md`) first.

1. Gather codebase context and draw the module dependency graph as Mermaid (Steps 0–1 of the guide)
2. Scan for each decay risk in the order specified (Steps 2–4 of the guide)
3. Run the Testability Seam Assessment (Step 5 of the guide)
4. Run the Conway's Law check (Step 6 of the guide)
5. Trace runtime callers and lifecycle constraints, then verify a proposed first refactoring step when one is in scope (Step 7 of the guide)
6. Assign node colors after all findings, then output using the Report Template from common.md — Mermaid graph FIRST, then Findings

**Mode line in report:** `Architecture Audit`
