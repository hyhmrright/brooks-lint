"""Run each guidance condition in an isolated writable fixture."""
import concurrent.futures
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
CONDITIONS = ("checklist", "audit-before", "audit-after")
BUDGET = int(os.getenv("REPLAY_BUDGET_SECONDS", "240"))
MODEL = os.getenv("REPLAY_MODEL", "gpt-6.1-terra")
CLI = shutil.which("codex")
AUTH_SOURCE = Path.home() / ".codex" / "auth.json"
SETTINGS = [
    "skills.bundled.enabled=false", "project_doc_max_bytes=0", "features.plugins=false",
    "features.apps=false", "features.hooks=false", "features.multi_agent=false",
    'web_search="disabled"', 'model_reasoning_effort="low"',
]
CONFIG = [argument for setting in SETTINGS for argument in ("-c", setting)]


def run(project, condition):
    fixture = Path(tempfile.mkdtemp(prefix=f"brooks-arm-{project}-", dir="/private/tmp"))
    repo = fixture / "repo"
    home = fixture / "home"
    codex_home = fixture / "codex"
    output = ROOT / os.getenv("REPLAY_OUTPUT", "results-proxy") / project / condition
    for directory in (repo, home, codex_home, output, fixture / "tmp"):
        directory.mkdir(parents=True, exist_ok=True)
    auth = codex_home / "auth.json"
    shutil.copyfile(AUTH_SOURCE, auth)
    auth.chmod(0o600)
    path = f'{ROOT}/pyright-node/node_modules/.bin:{ROOT}/venv-{project}/bin:{os.environ["PATH"]}'
    env = {
        "HOME": str(home), "CODEX_HOME": str(codex_home), "PATH": path,
        "TMPDIR": str(fixture / "tmp"), "LANG": "en_US.UTF-8",
        "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1",
        "PYTHONPATH": f"{repo}/src:{repo}", "PYTHONDONTWRITEBYTECODE": "1", "VIRTUAL_ENV": str(ROOT / f"venv-{project}"),
    }

    for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
                "http_proxy", "https_proxy", "all_proxy", "no_proxy",
                "SSL_CERT_FILE", "SSL_CERT_DIR", "NODE_EXTRA_CA_CERTS"):
        if key in os.environ:
            env[key] = os.environ[key]
    subprocess.run(["tar", "-xf", str(ROOT / f"{project}-base.tgz"), "-C", str(repo)], check=True, env=env)
    if project == "platformdirs":
        shutil.copyfile(ROOT / "support/platformdirs-version.py", repo / "src/platformdirs/version.py")
    for args in (["init", "-q"], ["add", "-f", "."], ["-c", "user.name=Replay", "-c",
                  "user.email=replay@example.invalid", "commit", "-qm", "Fixture"]):
        subprocess.run(["git", *args], cwd=repo, env=env, check=True)
    protocol = ROOT / "protocol"
    blocks = [(protocol / "common-prompt.txt").read_text(), (protocol / f"{project}.task").read_text()]
    if condition == "checklist":
        blocks.append("Assigned guidance:\n" + (protocol / "checklist.txt").read_text())
    else:
        shutil.copytree(ROOT / condition / "skills", repo / ".agents" / "skills")
        blocks.append("Apply the supplied $brooks-audit. Read .agents/skills/brooks-audit/SKILL.md and its referenced setup files. The shared assignment and JSON delivery format above apply.")
    prompt = os.getenv("REPLAY_PREFLIGHT") or "\n\n".join(blocks)
    (output / "prompt.txt").write_text(prompt)
    cli = [
        CLI, "--no-daemon", "-a", "never", "-C", str(repo), "-m", MODEL, *CONFIG,
        "exec", "--json", "--ephemeral", "--ignore-user-config", "--ignore-rules",
        "-s", "workspace-write", "--output-last-message", str(output / "answer.txt"), "-",
    ]
    started = time.monotonic()
    timed_out = False
    try:
        with (output / "events.jsonl").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
            process = subprocess.Popen(cli, cwd=repo, env=env, stdin=subprocess.PIPE,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                process.communicate(prompt.encode(), timeout=BUDGET)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
        (output / "run.json").write_text(json.dumps({
            "wall_seconds": round(time.monotonic() - started, 2), "wall_budget_seconds": BUDGET,
            "model": MODEL, "reasoning_effort": "low", "status": process.returncode,
            "timed_out": timed_out,
        }, indent=2) + "\n")
        candidate = subprocess.check_output(
            ["git", "ls-files", "--others", "--exclude-standard", "-z"], cwd=repo, env=env
        ).decode().split("\0")
        # Include all nonignored new files in the unmodified submission. Only
        # runner-provided skill guidance is excluded.
        new_files = [name for name in candidate if name and not name.startswith(".agents/skills/")]
        if new_files:
            subprocess.run(["git", "add", "-N", "--", *new_files], cwd=repo, env=env, check=True)
        with (output / "candidate.patch").open("wb") as patch:
            subprocess.run(["git", "diff", "--binary", "HEAD", "--", ".", ":(exclude).agents/skills"],
                           cwd=repo, env=env, stdout=patch, check=True)
        print(project, condition, process.returncode, timed_out, flush=True)
    finally:
        auth.unlink(missing_ok=True)


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for project in sys.argv[1:]:
        list(pool.map(lambda condition: run(project, condition), CONDITIONS if not os.getenv("REPLAY_PREFLIGHT") else ("checklist",)))
