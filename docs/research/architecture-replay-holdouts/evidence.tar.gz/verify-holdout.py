"""Replay unmodified candidate artifacts and isolate admitted mutations."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PROJECTS = ("markdown", "markdown-it")
ARMS = ("checklist", "audit-before", "audit-after")


def verify(project, arm):
    root = ROOT / project
    result = root / "verification" / arm
    logs = result / "logs"
    logs.mkdir(parents=True)
    tree = result / "tree"
    tree.mkdir()
    with tarfile.open(root / f"{project}-base.tgz") as archive:
        archive.extractall(tree, filter="data")
    bin_dir = root / f"venv-{project}/bin"
    status = {}

    def run(name, *command, cwd=tree):
        env = dict(os.environ, PYTHONPATH=str(cwd), PATH=f"{bin_dir}:{os.environ['PATH']}")
        env.pop("PYTEST_ADDOPTS", None)
        try:
            completed = subprocess.run(command, env=env, cwd=cwd, capture_output=True, timeout=80)
            code = completed.returncode
            output = completed.stdout + completed.stderr
        except subprocess.TimeoutExpired as exc:
            code = 124
            output = (exc.stdout or b"") + (exc.stderr or b"")
        log = logs / f"{name}.log"
        log.write_bytes(("$ " + " ".join(map(str, command)) + "\n").encode() + output + f"\nEXIT {code}\n".encode())
        status[name] = code
        return code, log

    if arm != "base":
        patch = root / f"results-proxy/{project}/{arm}/candidate.patch"
        if run("apply-check", "git", "apply", "--check", patch)[0]:
            return status
        run("apply", "git", "apply", patch)
        run("changed", "git", "apply", "--numstat", patch)
    pkg = "markdown" if project == "markdown" else "markdown_it"
    suite = ("python", "-m", "unittest", "discover", "-s", "tests") if project == "markdown" else (
        "python", "-m", "pytest", "-q", "tests"
    )
    run("suite", *suite)
    run("compile", "python", "-m", "compileall", "-q", pkg, "tests")
    run("probe", "python", root / "protocol/probe.py")
    if project == "markdown":
        run("flake8", "flake8", pkg, "tests")
    else:
        run("mypy", "mypy", pkg, "tests")
        run("ruff", "ruff", "check", "--no-fix", ".")
        run("ruff-format", "ruff", "format", "--check", ".")
        style = result / "style"
        shutil.copytree(tree, style, ignore=shutil.ignore_patterns(".*cache", "__pycache__"))
        ignored = re.compile(
            r"\.vscode/settings\.json|test.*\.(md|txt|html|xml)|.*commonmark\.json|benchmark/.*\.md|.*/spec\.md"
        )
        files = [p.relative_to(style).as_posix() for p in sorted(style.rglob("*"))
                 if p.is_file() and not ignored.search(p.relative_to(style).as_posix())
                 and b"\0" not in p.read_bytes()[:4096]]
        for hook, endings in (("check-json", (".json",)), ("check-yaml", (".yaml", ".yml")),
                              ("end-of-file-fixer", None), ("trailing-whitespace-fixer", None)):
            candidates = [f for f in files if endings is None or Path(f).suffix in endings]
            run(hook, hook, *candidates, cwd=style)

    collect_target = "tests/test_apis.py" if project == "markdown" else "tests"
    collect = ("python", "-m", "pytest", "-q", "--collect-only", collect_target)
    _, own_log = run("collect", *collect)
    if arm == "base":
        return status
    _, base_log = run("base-collect", *collect, cwd=root / "base")
    def nodes(log):
        return {line for line in log.read_text().splitlines() if line.startswith("tests/") and "::" in line}
    added = sorted(nodes(own_log) - nodes(base_log))
    status["added-test-nodes"] = added
    mutant = result / "mutant"
    shutil.copytree(tree, mutant, ignore=shutil.ignore_patterns(".*cache", "__pycache__"))
    command = (("python", root / "protocol/mutate.py", mutant) if project == "markdown" else
               ("git", "apply", root / "protocol/renderer-mutation.patch"))
    if run("plant", *command, cwd=mutant)[0] == 0:
        run("planted-probe", "python", root / "protocol/probe.py", cwd=mutant)
        run("planted-suite", *suite, cwd=mutant)
        if added:
            report = logs / "planted-authored.xml"
            run("planted-authored", "python", "-m", "pytest", "-q",
                f"--junitxml={report}", *added, cwd=mutant)
            if report.is_file():
                status["authored-failures"] = [
                    entry.get("message") for entry in ET.parse(report).findall(".//testcase/failure")
                ]
    return status


if __name__ == "__main__":
    names = [(project, arm) for project in PROJECTS for arm in (sys.argv[1:] or ("base", *ARMS))]
    with ThreadPoolExecutor(max_workers=4) as workers:
        report = dict(zip((f"{project}/{arm}" for project, arm in names),
                          workers.map(lambda pair: verify(*pair), names), strict=True))
    print(json.dumps(report, indent=2))
