import xml.etree.ElementTree as etree

from markdown import Markdown
from markdown.blockparser import BlockParser
from markdown.blockprocessors import ParagraphProcessor
from markdown.extensions import Extension


class ReplacementRootParser(BlockParser):
    @property
    def root(self):
        return self._conversion_root

    @root.setter
    def root(self, value):
        # Keep one extension-owned canonical element for this parse.
        self._conversion_root = None if value is None else etree.Element(value.tag, value.attrib)


class ParserExtension(Extension):
    def extendMarkdown(self, markdown):
        parser = ReplacementRootParser(markdown)
        parser.blockprocessors.register(ParagraphProcessor(parser), "paragraph", 10)
        markdown.parser = parser


markdown = Markdown(extensions=[ParserExtension()])
converted = markdown.convert("visible paragraph")
print(repr(converted))
assert converted == "<p>visible paragraph</p>"
