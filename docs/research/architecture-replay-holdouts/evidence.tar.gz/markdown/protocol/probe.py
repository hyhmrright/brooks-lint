"""Verify custom postprocessors observe the active source and parsed tree."""
from io import BytesIO

from markdown import Markdown
from markdown.extensions import Extension
from markdown.postprocessors import Postprocessor


class ObserveState(Postprocessor):
    def run(self, text):
        source = self.md.lines
        root = self.md.parser.root
        assert root is not None and source, "postprocessor lost active document state"
        assert root[0].text == source[0]
        return f"{text} [{source[0]}]"


class Observer(Extension):
    def extendMarkdown(self, md):
        md.postprocessors.register(ObserveState(md), "observe-document", 0)


markdown = Markdown(extensions=[Observer()])
assert markdown.convert("first") == "<p>first</p> [first]"
markdown.reset()
result = BytesIO()
assert markdown.convertFile(BytesIO(b"second"), result) is markdown
assert result.getvalue() == b"<p>second</p> [second]"
