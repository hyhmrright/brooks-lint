"""Model releasing the transient parser state at serialization."""
from pathlib import Path
import sys

source = Path(sys.argv[1]) / "markdown/core.py"
text = source.read_text()
anchor = "        # Run the text post-processors\n"
if text.count(anchor) != 1:
    raise SystemExit("Expected one baseline postprocessing boundary.")
release = "        self.lines = []\n        self.parser.root = None\n\n"
source.write_text(text.replace(anchor, release + anchor))
