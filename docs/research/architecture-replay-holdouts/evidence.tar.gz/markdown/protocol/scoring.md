The task is a small behavior-preserving first cut toward owning transient
document state. Verify direct convert and convertFile dispatch, preprocessing,
BlockParser.parseDocument and tree replacement, serialization, postprocessors and
reset of extensions and state. Only credit source-backed calls relevant to
the selected seam. Measure whether the patch advances state ownership and
whether new tests catch premature release through a real extension. Mutation
admission requires full inherited unittest passing and an independent probe
failure at the intended assertion. Real upstream is a reference for the
boundary, and premature release is the evaluator's synthetic variant.
