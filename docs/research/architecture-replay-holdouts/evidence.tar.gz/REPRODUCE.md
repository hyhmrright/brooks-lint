# Holdout evidence replay

Run `shasum -a 256 -c SHA256SUMS` from the extracted evidence root. The
bundled source archives are uncompressed Git tar archives pinned in
`markdown/refs.txt` and `markdown-it/refs.txt`. Logs preserve historical
workspace paths.

Create the same Python 3.11 environments using uv. For each case, extract
its source and install the local baseline package as shown below. The
historical single-line local requirement is filtered so it can be recreated
at the new archive path.

```sh
for case_name in markdown markdown-it; do
  (
    cd "$case_name"
    mkdir base
    tar -xf "$case_name-base.tgz" -C base
    uv venv --python 3.11 "venv-$case_name"
    lock=requirements.freeze
    if [ "$case_name" = markdown-it ]; then lock=requirements.static.freeze; fi
    sed '/ @ file:\/\//d' "$lock" > external-requirements.txt
    uv pip sync --python "venv-$case_name/bin/python" external-requirements.txt
    uv pip install --python "venv-$case_name/bin/python" --no-deps --no-build-isolation ./base
    mv verification recorded-verification
  )
done
python3 verify-holdout.py
```

The Markdown Pygments profile is in `markdown/requirements.pygments.freeze`.
It uses the same local package build and sets `PYGMENTS_VERSION=2.7.1` when
running unittest discovery. The Markdown descriptor probe and reference patch
are in `markdown/post-hoc`. The Markdown-it dispatch-only diagnostic applies
the supplied `assembly-diagnostic/dispatch-only.patch` after the base or
older-audit patch, then runs the frozen probe and complete pytest suite.

The Blinker control receipts use the command documented in
`evals/research/architecture-replay/README.md` of the brooks-lint repository.
The typing-compatible control is an additional patch for `--patch`.

Optional live replays with `run_arms.py` need an authenticated Codex CLI and a
new output directory. No model calls are made when replaying frozen patches.
