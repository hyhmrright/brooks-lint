# Recovery QA round 1 — FAIL

All three original recovery tests passed (46.149 seconds; no skips). Static boundary audit and an offline reproduction found that `readRecovery` accepted an arbitrary execution.json without checking it: a sealed parent with no recovery intents verified while the summary claimed 132 completed and 133 attempts, versus the actual 11 completed and 12 attempts. This undermines the published terminal status verification contract. The reproduction made no model calls.

Additional replay gaps: cumulative-token admission was enforced during execution but not reconstructed during verification; recovery duration fields lacked the finite/nonnegative check used for parent records. Requested author fixes and regression coverage. Frozen sources and original evidence were not modified. Recovery is not approved for execution by this QA record.
